
package com.hca.nwproductsbycategory;

import com.mysql.jdbc.jdbc2.optional.*;
import java.sql.*;
import java.util.Scanner;
import javax.sql.DataSource;

public class ProductsByCategoryDataMgr2 {

	public static void main(String[] args) {
		
		// check for bad args
		if (args.length != 2) {
			System.out.println("Must include username & password on command line.");
			System.exit(1);
		}
		
		String username = args[0];
		String password = args[1];
		
		// try to set driver
		try {
			
			// non-data-source method
			// Class.forName("com.mysql.jdbc.Driver"); 
			// String dbURL = "jdbc:mysql://localhost:3306/northwind";
			
			// create & configure data source
			MysqlDataSource source = new MysqlDataSource();
			source.setServerName("localhost");
			source.setPort(3306);
			source.setUser(username);
			source.setPassword(password);
			source.setDatabaseName("Northwind");
			
			// first query
			doCategoryQuery(source);
			
			// get user input
			Scanner scanner = new Scanner(System.in);
			System.out.print("Which category do you want to see the products for? ");
			int category = scanner.nextInt();
			scanner.nextLine();
			
			// second query
			doProductsQuery(source, category);
			
			
		} catch (Exception e) {
			
			System.out.println("ERROR: Failed somewhere.");
			e.printStackTrace();
			
		} // end try to set driver with SQL Exception, Exception
		
	}
	
	private static void doCategoryQuery(DataSource source) {
		
		// try to connect to db
		try (
				Connection connection = source.getConnection();
				PreparedStatement sCategories = connection.prepareStatement(
					"SELECT CategoryID, CategoryName " +
					"FROM categories"
				);
			) {
			
			// try to query categories
			try (ResultSet results = sCategories.executeQuery()) {
				
				while (results.next()) {
					System.out.printf("%2d | %s\n", results.getInt(1), results.getString(2));
				}
				
			} catch (SQLException e) {
				
				System.out.println("ERROR: Failed to get categories.");
				e.printStackTrace();
				
			} // end try to query categories with SQLException
			
		} catch (SQLException e) {
			
			System.out.println("ERROR: Failed to connect to database.");
			e.printStackTrace();
			
		} // end try to connect to db with SQLException
		
	}
	
	private static void doProductsQuery(DataSource source, int category) {
		
		// try to connect to db
		try (
			Connection connection = source.getConnection();
			PreparedStatement sProducts = connection.prepareStatement(
				"SELECT ProductID, ProductName, UnitPrice, UnitsInStock " +
				"FROM products " +
				"WHERE CategoryID = ?"
			);
		) {
			
			sProducts.setInt(1, category);
			
			// try to query products
			try (ResultSet results = sProducts.executeQuery()) {
				
				System.out.printf("%-12s | %-42s | %16s | %14s\n", "Product ID", "Product Name", "Unit Price", "Units In Stock");
				System.out.printf("%-12s | %-42s | %16s | %14s\n", "----------", "------------", "----------", "--------------");
				
				while (results.next()) {	
					System.out.printf("%-12d | %-42s | %16.2f | %14d\n", results.getInt(1), results.getString(2), results.getFloat(3), results.getInt(4));	
				}
				
			} catch (SQLException e) {
				
				System.out.println("ERROR: Failed to get products.");
				e.printStackTrace();
				
			} // end try to query products with SQLException
			
		} catch (SQLException e) {
			
			System.out.println("ERROR: Failed to connect to database.");
			e.printStackTrace();
			
		} // end try to connect to db with SQLException
		
		
	}

}