package com.hca.nwproductsbycategory;

import java.sql.*;
import java.util.*;

public class ProductsByCategoryQueryApp {

	public static void main(String[] args) {

		if (args.length != 2) {
			System.out.println("Must include username and password on command line.");
			// this stops the program
			System.exit(1);
		}

		// gets the username and password from the arguments
		String username = args[0];
		String password = args[1];

		// load MYSQL driver
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("MySQL driver not loaded!");
			e.printStackTrace();
			System.exit(1);
		}

		// creates a connection to our database with necessary credentials
		try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind", username,
				password);
				PreparedStatement statement = connection
						.prepareStatement("SELECT CategoryID, CategoryName FROM categories ORDER BY categoryid");

				ResultSet results = statement.executeQuery()) {
			System.out.println("Our Categories Are: ");
			while (results.next()) {
				System.out.printf("ID = %d Name= %s \n", results.getInt(1), results.getString(2));
			}
		} catch (SQLException e1) {
			System.out.println("ERROR in catch block for execute query");
			e1.printStackTrace();
		}

		Scanner scanner = new Scanner(System.in);
		System.out.print("Please enter category ID you would like to see products for?");
		int category = scanner.nextInt();
		scanner.nextLine();

		try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind", username,
				password);) {
			PreparedStatement statement = connection.prepareStatement(
					"SELECT productid, productname, unitprice, unitsinstock FROM products WHERE category = ?");
			statement.setInt(1, category);

			try (ResultSet results = statement.executeQuery()) {
				// printing headings
				System.out.printf("%-2s  %-33s  %10s  %14s %17s\n", "ID", "Product Name", "Price", "Units in Stock",
						"Cost of Inventory");
				System.out.printf("%-2s  %-33s  %10s  %14s %17s\n", "--", "------------", "-----", "--------------",
						"-----------------");
				// loop through results as long as next() returns true ie as long as there are
				// results are left to examine
				while (results.next()) {
					// Get the 1st and 2nd fields returned from the query
					// based on the SELECT statement - // SQL is 1 based index not 0 based index --
					// results can be used with the index location or the name of the variable from
					// line 41
					System.out.printf(" %2d %-33s %10.2f %14s %17.2f\n", results.getInt("ProductID"),
							results.getString("ProductName"), results.getFloat(3), results.getString(4),
							results.getFloat(5));
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		scanner.close();
	}
}
