package com.hca.nwproductsbycategory;

import java.sql.*;
import java.util.Scanner;

public class ProductsByCategoryQueryApp2 {

	public static void main(String[] args) {

		// check for bad args
		if (args.length != 2) {
			System.out.println("Must include username & password on command line.");
			System.exit(1);
		}

		String username = args[0];
		String password = args[1];

		// try driver
		try {

			Class.forName("com.mysql.jdbc.Driver");

		} catch (ClassNotFoundException e) {

			System.out.println("ERROR: Driver not loaded!");
			e.printStackTrace();
			System.exit(1);

		}

		// connect to db
		String dbURL = "jdbc:mysql://localhost:3306/northwind";
		try (Connection connection = DriverManager.getConnection(dbURL, username, password);) {

			PreparedStatement sCategory = connection.prepareStatement(
				"SELECT CategoryID, CategoryName " +
				"FROM categories"
			);

			try (ResultSet results = sCategory.executeQuery()) {

				while (results.next()) {

					System.out.printf("%2d | %s\n", results.getInt(1), results.getString(2));

				}

			} catch (SQLException e) {

				System.out.println("ERROR: Failed to get categories.");
				e.printStackTrace();

			}

			Scanner scanner = new Scanner(System.in);
			System.out.print("Which category do you want to see the products for? ");
			int category = scanner.nextInt();
			scanner.nextLine();

			PreparedStatement sProducts = connection.prepareStatement(
				"SELECT ProductID, ProductName, UnitPrice, UnitsInStock " +
				"FROM products " +
				"WHERE CategoryID = ?"
			);
			sProducts.setInt(1, category);

			try (ResultSet results = sProducts.executeQuery()) {

				System.out.printf("%-12s | %-42s | %16s | %14s\n", "Product ID", "Product Name", "Unit Price", "Units In Stock");
				System.out.printf("%-12s | %-42s | %16s | %14s\n", "----------", "------------", "----------", "--------------");

				while (results.next()) {

					System.out.printf("%-12d | %-42s | %16.2f | %14d\n", results.getInt(1), results.getString(2), results.getFloat(3), results.getInt(4));

				}

			} catch (SQLException e) {

				System.out.println("ERROR: Failed to get products.");
				e.printStackTrace();

			}

		} catch (Exception e) {

			System.out.println("ERROR: Failed somewhere.");
			e.printStackTrace();

		}


	}

}