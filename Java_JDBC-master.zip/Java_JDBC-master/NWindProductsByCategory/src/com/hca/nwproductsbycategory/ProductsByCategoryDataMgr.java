package com.hca.nwproductsbycategory;

// all necessary imports 

import com.mysql.jdbc.jdbc2.optional.*;
import java.sql.*;
import java.util.Scanner;

import javax.activation.*;
import javax.activation.DataSource;
import javax.sql.*;

// new class
public class ProductsByCategoryDataMgr {

	public static void main(String[] args) {

		// check for bad args
		if (args.length != 2) {
			System.out.println("Must include username & password on command line.");
			System.exit(1);
		}

		// get username and pass from args
		String username = args[0];
		String password = args[1];

		// creates the new data source to hold the following properties
		MysqlDataSource mysqlDataSource = new MysqlDataSource();

		// properties and configurations for the data source
		mysqlDataSource.setServerName("localhost");
		mysqlDataSource.setPort(3306);
		mysqlDataSource.setUser(username);
		mysqlDataSource.setPassword(password);
		mysqlDataSource.setDatabaseName("northwind");

		// queries the database from line 30 this is the first query - this has the get
		// connection
		doFirstCatQuery(mysqlDataSource);
	}

	private static void doFirstCatQuery(MysqlDataSource mysqlDataSource) {
		// Create the connection and prepared statement
		try (Connection connection = mysqlDataSource.getConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement("SELECT CategoryID, CategoryName " + "FROM categories");) {
			// Set any required parameters here
			// Execute the query
			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				// Process the results
				System.out.println("Our Categories Are: ");
				while (resultSet.next()) {
					System.out.printf("ID = %s, CATEGORY = %s;\n", resultSet.getString(1), resultSet.getString(2));
				}
				//				 complete second query
				// scans and traps the info from the user
				Scanner scanner = new Scanner(System.in);
				System.out.print("Please enter category ID you would like to see products for?");
				int category = scanner.nextInt();
				scanner.nextLine();
				try (Connection connection1 = mysqlDataSource.getConnection();) {
					PreparedStatement statement = connection1.prepareStatement(
							"SELECT productid, productname, unitprice, unitsinstock FROM products WHERE category = ?");
					statement.setInt(1, category);

					try (ResultSet results = statement.executeQuery()) {
						// printing headings
						System.out.printf("%-2s  %-33s  %10s  %14s %17s\n", "ID", "Product Name", "Price",
								"Units in Stock", "Cost of Inventory");
						System.out.printf("%-2s  %-33s  %10s  %14s %17s\n", "--", "------------", "-----",
								"--------------", "-----------------");
						// loop through results as long as next() returns true ie as long as there are
						// results are left to examine
						while (results.next()) {
							// Get the 1st and 2nd fields returned from the query
							// based on the SELECT statement - // SQL is 1 based index not 0 based index --
							// results can be used with the index location or the name of the variable from
							// line 41
							System.out.printf(" %2d %-33s %10.2f %14s %17.2f\n", results.getInt("ProductID"),
									results.getString("ProductName"), results.getFloat(3), results.getString(4),
									results.getFloat(5));
						}
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				scanner.close();
			}

		} catch (SQLException e) {
			// This will catch all SQLExceptions occurring
			// in the try block, including those in nested
			// try statements
			e.printStackTrace();
		}

	}

}