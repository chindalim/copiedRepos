package com.hca.sakilaactors;

// required imports

import javax.sql.*;
import java.sql.*;
import java.util.Scanner;

import com.mysql.jdbc.jdbc2.optional.*;

public class DataSourceQueryApp {

	public static void main(String[] args) {

//		call to args in run configuration 
		if (args.length != 2) {
			System.out.println("Must include username and password on command line.");
//			this stops the program
			System.exit(1);
		}

//		gets the username and password from the arguments
		String username = args[0];
		String password = args[1];

//		creating the connection assigning new var to mysqlDS	
		MysqlDataSource mysqlDS = new MysqlDataSource();

//	configuring and holding the properties for the new datasource

		mysqlDS.setServerName("localhost");
		mysqlDS.setPort(3306);
		mysqlDS.setUser(username);
		mysqlDS.setPassword(password);
		mysqlDS.setDatabaseName("sakila");

////	helper method to interact with the database
//		doLastNameQuery(mysqlDS);
//
//	}
//
//	private static void doLastNameQuery(MysqlDataSource mysqlDS) {
//		scanner to read in response
		Scanner scanner = new Scanner(System.in);
		System.out.println("Please enter the last name of the actor's body of work you would like to view");
		String lastName = scanner.nextLine();
		scanner.nextLine();

		try (Connection connection = mysqlDS.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(
						"SELECT first_name, last_name FROM actor" + " WHERE last_name LIKE ? ORDER BY first_name");) {
			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				while (resultSet.next()) {
					System.out.printf("first_name = %s, last_name = %s;\n", resultSet.getString(1),
							resultSet.getString(2));
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
