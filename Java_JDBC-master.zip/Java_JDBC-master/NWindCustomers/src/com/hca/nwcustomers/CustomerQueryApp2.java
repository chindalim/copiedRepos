package com.hca.nwcustomers;

import java.sql.*;
import java.util.*;

public class CustomerQueryApp2 {

	public static void main(String[] args) {

//		load MYSQL driver
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (args.length != 2) {
			System.out.println("Must include username and password on command line.");
//				this stops the program
			System.exit(0);
		}

//			gets the username and password from the arguments
		String username = args[0];
		String password = args[1];

//		creates a connection to our database with necessary credentials
		Connection connection = null;
		try {
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind", username,
					password);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

//		creates a statement to be executed with a query
		PreparedStatement statement = null;
		try {
			statement = connection
//		question mark leaves a placeholder for the maxPrice parameter to be added.
					.prepareStatement("SELECT ContactName, CompanyName, City, Country, Phone FROM customers");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
//		setting value for the parameter

//printing headings
		System.out.printf("%-26s  %-37s  %-18s  %-15s %-12s\n", "Contact Name", "Company Name", "City", "Country",
				"Phone Number");
		System.out.printf("%-26s  %-37s  %-18s  %-15s %-12s\n", "------------", "------------", "----", "-------",
				"------------");
		ResultSet results = null;
		try {
			results = statement.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

//		loop through results as long as next() returns true ie as long as there are results are left to examine
		try {
			while (results.next()) {
				// Get the 1st and 2nd fields returned from the query
				// based on the SELECT statement - // SQL is 1 based index not 0 based index --
				// results can be used with the index location or the name of the variable from
				// line 41
				try {
					System.out.printf("%-26s  %-37s  %-18s  %-15s %-12s\n", results.getString(1),
							results.getString(2), results.getString(3), results.getString(4), results.getString(5));
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

//		closes the resources in the reverse order 
		try {
			results.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			statement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
