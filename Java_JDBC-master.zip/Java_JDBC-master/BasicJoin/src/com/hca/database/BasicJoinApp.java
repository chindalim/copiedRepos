package com.hca.database;

import java.sql.*;
import java.util.*;

public class BasicJoinApp {

	public static void main(String[] args) {

		if (args.length != 2) {
			System.out.println("Must include username and password on command line.");
			// this stops the program
			System.exit(1);
		}

		// gets the username and password from the arguments
		String username = args[0];
		String password = args[1];

		// load MYSQL driver
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(1);
		}

		// creates a connection to our database with necessary credentials
		try (
				Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind", username,password);
				PreparedStatement statement = connection.prepareStatement("SELECT employeeid, firstname FROM employees ORDER BY firstname");
				ResultSet results = statement.executeQuery();
				) {
			System.out.println("Our Employees Are: ");
			while (results.next()) {
				System.out.printf("ID = %d Name= %s \n", results.getInt(1), results.getString(2));
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			System.out.println("ERROR in catch block for execute query");
			e1.printStackTrace();
		}
	}
}


/*
lambdas
jsp
servlets
*/