package com.hca.nwproducts;

import java.sql.*;
import java.util.*;

public class ProductQueryApp {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {

//			load MYSQL driver
		Class.forName("com.mysql.jdbc.Driver");

//				display an error if user does not enter two command line args (username and password)
		if (args.length != 2) {
			System.out.println("Must include username and password on command line.");
//					this stops the program
			System.exit(0);
		}

//				gets the username and password from the arguments
		String username = args[0];
		String password = args[1];

		Scanner scanner = new Scanner(System.in);

//		ask user how much they're willing to pay for a product
		System.out.println("What is the maximum amount you are willing to pay for a product?");
		float maxPrice = scanner.nextFloat();

//				for learning purposes - displays the username and password
//		System.out.printf("Username %s, Password %s\n", username, password);

//				creates a connection to our database with necessary credentials
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind", username,
				password);

//				creates a statement to be executed with a query
		PreparedStatement statement = connection
//				question mark leaves a placeholder for the maxPrice parameter to be added.
				.prepareStatement(
						"SELECT ProductID, ProductName, UnitPrice, UnitsInStock, UnitPrice*UnitsInStock FROM products WHERE UnitPrice <= ?");
//				setting value for the parameter
		statement.setFloat(1, maxPrice);

//				executes the query and holds the results
		ResultSet results = statement.executeQuery();

//		printing headings
		System.out.printf("%-2s  %-33s  %10s  %14s %17s\n", "ID", "Product Name", "Price", "Units in Stock",
				"Cost of Inventory");
		System.out.printf("%-2s  %-33s  %10s  %14s %17s\n", "--", "------------", "-----", "--------------",
				"-----------------");

//				loop through results as long as next() returns true ie as long as there are results are left to examine
		while (results.next()) {
			// Get the 1st and 2nd fields returned from the query
			// based on the SELECT statement - // SQL is 1 based index not 0 based index --
			// results can be used with the index location or the name of the variable from
			// line 41
			System.out.printf(" %2d %-33s %10.2f %14s %17.2f\n", results.getInt("ProductID"),
					results.getString("ProductName"), results.getFloat(3), results.getString(4), results.getFloat(5));
		}

//				closes the resources in the reverse order 
		results.close();
		statement.close();
		connection.close();

	}
}
