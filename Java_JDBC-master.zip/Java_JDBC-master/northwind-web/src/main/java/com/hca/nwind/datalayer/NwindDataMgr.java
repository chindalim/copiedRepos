package com.hca.nwind.datalayer;

import java.util.*;
import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

import java.sql.*;
import com.hca.nwind.models.Category;
import com.hca.nwind.models.Product;

public class NwindDataMgr {

	private MysqlDataSource mysqlDS;

	public NwindDataMgr() {
		mysqlDS = new MysqlDataSource();
		mysqlDS.setServerName("localhost");
		mysqlDS.setPort(3306);
		mysqlDS.setUser("");
		mysqlDS.setPassword("");
		mysqlDS.setDatabaseName("northwind");
	}

	// cannot create a new list but we can create a new array list
	public List<Product> getAllProducts() {
		ArrayList<Product> list = new ArrayList<Product>();

		try (Connection connection = mysqlDS.getConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement("SELECT * FROM products ORDER BY productname");

				// getting the results from the database
				ResultSet results = preparedStatement.executeQuery()) {
			while (results.next()) {

				// int productId, int unitInStock, double unitPrice, String productName,
				// Category category
				Product product = new Product(results.getInt("productId"), results.getInt("unitsInStock"),
						results.getDouble("unitPrice"), results.getString("productName"), null);
				list.add(product);
			}

		} catch (SQLException e) {
			System.out
					.println("ERROR: Failed in the [NwindDataMgr:getAllProducts] method --- unable to fetch products");
			e.printStackTrace();
		}

		return list;
	}

	// gets all the categories and products
	public List<Product> getProductsByCategory(int categoryID) {
		ArrayList<Product> list = new ArrayList<Product>();

		try (Connection connection = mysqlDS.getConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement("SELECT * FROM products WHERE categoryID = ? ORDER BY productname");) {

			preparedStatement.setInt(1, categoryID);

			try ( // getting the results from the database - second try block since line 53 has
					// resources in it
					ResultSet results = preparedStatement.executeQuery())

			{
				while (results.next()) {

					// int productId, int unitInStock, double unitPrice, String productName,
					// Category category
					Product product = new Product(results.getInt("productId"), results.getInt("unitsInStock"),
							results.getDouble("unitPrice"), results.getString("productName"), null);
					list.add(product);
				}

			}

		} catch (SQLException e) {
			System.out
					.println("ERROR: Failed in the [NwindDataMgr:getAllProducts] method --- unable to fetch categories and products");
			e.printStackTrace();
		}

		return list;
	}

	public List<Category> getAllCategoriess() {
		ArrayList<Category> list = new ArrayList<Category>();

		try (Connection connection = mysqlDS.getConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement("SELECT * FROM categories ORDER BY categoryID");
				// getting the results from the database
				ResultSet results = preparedStatement.executeQuery();)

		{
			while (results.next()) {

				Category category = new Category(results.getInt("categoryId"), results.getString("categoryName"),
						results.getString("description"));
				list.add(category);
			}

		} catch (SQLException e) {
			System.out
					.println("ERROR: Failed in the [NwindDataMgr:getAllProducts] method --- unable to fetch products final catch statement");
			e.printStackTrace();
		}

		return list;
	}

}
