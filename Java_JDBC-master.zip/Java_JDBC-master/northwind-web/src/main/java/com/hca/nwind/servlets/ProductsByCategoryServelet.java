package com.hca.nwind.servlets;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hca.nwind.datalayer.NwindDataMgr;
import com.hca.nwind.models.Category;
import com.hca.nwind.models.Product;

/**
 * Servlet implementation class ProductsByCategoryServelet
 */
@WebServlet("/productsbycategory")
public class ProductsByCategoryServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductsByCategoryServelet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
//		sets the response type
		response.setContentType("text/html");
		
//		gets the data Category
		NwindDataMgr dataManager = new NwindDataMgr();
		List<Category> list = dataManager.getAllCategoriess();
		
//		saves Category in the request so they can be sent and displayed for the jsp
		request.setAttribute("categories", list);
//		title could be sent here as well
//		request.setAttribute("title", "All Products");

		
//		sends and dispatches request to the JSP
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/productsbycategory.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Map<String, String[]> parameterMap = request.getParameterMap();
		int categoryId =  Integer.parseInt(parameterMap.get("category")[0]);

		NwindDataMgr dataManager = new NwindDataMgr();
		List<Product> list = dataManager.getProductsByCategory(categoryId);

		request.setAttribute("products", list);
		request.setAttribute("selectedCategory", categoryId);
		
		doGet(request, response);
	}

}
