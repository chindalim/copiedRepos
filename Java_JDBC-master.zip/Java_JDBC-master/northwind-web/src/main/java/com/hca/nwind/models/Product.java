package com.hca.nwind.models;

public class Product {

	private int productId;
	private int unitsInStock;
	private double unitPrice;
	private String productName;
	private Category category;
// more product data columns can be added at a later time based on the database's column
	
	
	// constructor

	public Product(int productId, int unitsInStock, double unitPrice, String productName, Category category) {
		super();
		this.productId = productId;
		this.unitsInStock = unitsInStock;
		this.unitPrice = unitPrice;
		this.productName = productName;
		this.category = category;
	}

	// getters and setters
	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getUnitsInStock() {
		return unitsInStock;
	}

	public void setUnitsInStock(int unitsInStock) {
		this.unitsInStock = unitsInStock;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	// to string method

	@Override
	public String toString() {
		return String.format("Product [productId=%s, unitsInStock=%s, unitPrice=%s, productName=%s, category=%s]",
				productId, unitsInStock, unitPrice, productName, category);
	}

}
