package com.hca.database;

import java.sql.*;

public class BasicQueryApp {

//	not a best practice but acknowledges that the throws exception might throw an exception but we want the exception is to be ignored. -- TRY CATCH is a better method
//	SQLEception is thrown for the connection 
	public static void main(String[] args) throws ClassNotFoundException, SQLException {

//	load MYSQL driver
		Class.forName("com.mysql.jdbc.Driver");

//		display an error if user does not enter two command line args (username and password)
		if (args.length != 2) {
			System.out.println("Must include username and password on command line.");
//			this stops the program
			System.exit(0);
		}

//		gets the username and password from the arguments
		String username = args[0];
		String password = args[1];

//		for learning purposes - displays the username and password
//		System.out.printf("Username %s, Password %s\n", username, password);

//		creates a connection to our database with necessary credentials
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sakila", username, password);

//		creates a statement to be executed with a query
		PreparedStatement statement = connection.prepareStatement("SELECT category_id, name FROM category");

//		executes the query and holds the results
		ResultSet results = statement.executeQuery();

//		loop through results as long as next() returns true ie as long as there are results are left to examine
		while (results.next()) {
			// Get the 1st and 2nd fields returned from the query
			// based on the SELECT statement - // SQL is 1 based index not 0 based index
			System.out.printf("Category ID = %d, Name = %s\n", results.getInt(1), results.getString(2));
		}
		
//		closes the readers 
		results.close();
		statement.close();
		connection.close();

	}

}
