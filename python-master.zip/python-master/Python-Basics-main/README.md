# Python-Getting Started


Resources:

https://www.geeksforgeeks.org/dunder-magic-methods-python/