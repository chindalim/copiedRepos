## Directory Structure

The directory structure of this repo contains:

```
├── .github                     <- Templates for Github issues, pull requests, etc.
|
├── docs                        <- files related to documentation/github page
│
├── src                         <- Source code for use in Dragon project
│   │
|   └── __init__.py             <- Required for referencing .py scripts across structure 
|   |
│   └── data                    <- Directory contains static csv files for reference tables
│   │
│   └── services                <- Directory contains services that can be used for tasks that are performed frequently
│
├── test                        <- Unit testing
| 
├── .gitignore                  <- Helper for repo hygiene; file extensions of files for Git to ignore
|
├── README.md                   <- Top-level README abstract for developers using this project.
|
├── VERSION                     <- Optional: track the version of your asset
|
├── requirements.txt            <- List of requirements for reproducing the analysis environment, e.g. python library versions
│
└── zip.yaml                    <- Jenkins build configuration
```
