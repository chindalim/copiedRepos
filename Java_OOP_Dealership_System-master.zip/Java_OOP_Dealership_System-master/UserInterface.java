import java.util.*;

public class UserInterface {

  // scans in keyboard values/inputs
  Scanner scanner = new Scanner(System.in);
  Dealership dealership = null;
  DealershipFileMgr dealershipFileMgr = null;
  
  private void init() {
    // the private init() method. In this method, you need to create your dealership object. To do this, 1) create an instance of your DealershipFileManager class, 2) call its getDealership() method, and 3) assign the dealership that it returns to the UserInterface's this.dealership attribute.
      // file manager - updated to this. for scoping - as variable was declared above
    this.dealershipFileMgr = new DealershipFileMgr();  
 
    // pulls in the info from dealership data mgr and creates a new dealership variable  
    this.dealership = dealershipFileMgr.getDealership();
  }

  // empty constructor since the dealership is being passed above - this does not need to be passed to the program.java file
  public UserInterface() {
  }

  // creates the display method 
  public void display() {
    // allows access to the private init
    init();
    // displayAllVehicles();

    int command = -1;

    while (command != 99) {
      displayMenu();
      command = scanner.nextInt();
      scanner.nextLine();

      switch (command) {
      case 1:
        processGetByPriceRequest();
        break;
      case 2:
        processGetByMakeModelRequest();
        break;
      case 3:
        processGetByYearRequest();
      break;
      case 4:
        processGetByColorRequest();
        break;
      case 5:
        processGetByMilageRequest();
        break;
      case 6:
        processGetByTypeRequest();
        break;
      case 7:
        displayAllVehicles();
        break;
      case 8:
        processAddVehicleRequest();
        break;
      case 9:
        processRemoveRequest();
        break;
      case 10:
        SearchByTerm();
        break;
      case 11:
        SortByYear();
        break;
      case 12:
        break;
      case 13:
        break;
      case 14:
        break;
      default:
        break;
      }
    }
    // System.print
  }

  public void displayMenu() {
    System.out.println("\n*** Welcome to " + dealership.getName() + "! *** \n What would you like to do?\n");
    System.out.println("1- Get Vehicles By - Price");
    System.out.println("2- Get Vehicles By - Make and Model");
    System.out.println("3-  Get Vehicles By - Year");
    System.out.println("4- Get Vehicles By - Color");
    System.out.println("5- Get Vehicles By - Milage");
    System.out.println("6- Get Vehicles By - Type");
    System.out.println("7- List All Vehicles");
    System.out.println("8- Add A Vehicle");
    System.out.println("9- Remove a Vehicle");
    System.out.println("10- Search by term?");
    // System.out.println("11- Sort by Year");
    // System.out.println("12- Sort by Model");
    // System.out.println("13- Sort by Color");
    // System.out.println("14- Sort by Milage?");
    System.out.println("99 - quit");
  }


// start of all methods
  // // need to pass in UI - refactor code
  // public void displayVehicleInfo() {
  //   ArrayList<Vehicle> vehiclesArr = dealership.getAllVehicles();
  // }

  // private displayVehicles() helper method
  private void displayAllVehicles() {
    // array list of Vehicle from dealership called vehicles  & pulls the method from the Dealership.java file and calls on the getAllVehicles method
    ArrayList<Vehicle> vehiclesArr = dealership.getAllVehicles();
    System.out.println("We currently have " + vehiclesArr.size() + " vehicles \n");
    // for loop for one vehicle in the array of vehicles
    for (Vehicle vehicle : vehiclesArr) {
      System.out.println("Vin: " + vehicle.getVin() + " - " + vehicle.getMake() + " " + vehicle.getModel() + " " + vehicle.getYear() + " " + vehicle.getColor() + " - Odometer: " + vehicle.getOdometer() + " " + vehicle.getVehicleType() + " -  MSRP: " + vehicle.getPrice());
    }   
  }
  
// all process methods
  public void processGetByPriceRequest() {
    System.out.print("What is your budget? \n"); 
    System.out.print("Minimum price: ");
    double min = scanner.nextDouble();
    System.out.print("Maximum price: ");
    double max = scanner.nextDouble();

    // data type is not required when passing params
    ArrayList<Vehicle> vehiclesArr = dealership.getVehiclesByPrice(min, max);

    // move to a display all method
    System.out.println("We currently have " + vehiclesArr.size() + " vehicles in this price range \n");

    // for loop for one vehicle in the array of vehicles
    for (Vehicle vehicle : vehiclesArr) {
      System.out.println("Vin: " + vehicle.getVin() + " - " + vehicle.getMake() + " " + vehicle.getModel() + " " + vehicle.getYear() + " " + vehicle.getColor() + " - Odometer: " + vehicle.getOdometer() + " " + vehicle.getVehicleType() + " -  MSRP: " + vehicle.getPrice());
    } 
  }

  public void processGetByMakeModelRequest() {
    System.out.print("What make would you like? \n"); 
    String make = scanner.nextLine().trim().toLowerCase();
      System.out.print("What model would you like? \n"); 
    String model = scanner.nextLine().trim().toLowerCase();
    int matchedVehicles = 0;

    ArrayList<Vehicle> vehiclesArr = dealership.getVehiclesByMakeModel(make, model);
    
    System.out.println("We currently have " + vehiclesArr.size() + " vehicles matching the requested make and model. \n");
        // for loop for one vehicle in the array of vehicles
    for (Vehicle vehicle : vehiclesArr) {
      System.out.println("Vin: " + vehicle.getVin() + " - " + vehicle.getMake() + " " + vehicle.getModel() + " " + vehicle.getYear() + " " + vehicle.getColor() + " - Odometer: " + vehicle.getOdometer() + " " + vehicle.getVehicleType() + " -  MSRP: " + vehicle.getPrice());
    } 
  }

  public void processGetByYearRequest() {
    System.out.print("Minimum year: ");
    int min = scanner.nextInt();
    System.out.print("Maximum year: ");
    int max = scanner.nextInt();

    // data type is not required when passing params
    ArrayList<Vehicle> vehiclesArr = dealership.getVehiclesByYear(min, max);

    // move to a display all method
    System.out.println("We currently have " + vehiclesArr.size() + " vehicles in this year range \n");

    // for loop for one vehicle in the array of vehicles
    for (Vehicle vehicle : vehiclesArr) {
      System.out.println("Vin: " + vehicle.getVin() + " - " + vehicle.getMake() + " " + vehicle.getModel() + " " + vehicle.getYear() + " " + vehicle.getColor() + " - Odometer: " + vehicle.getOdometer() + " " + vehicle.getVehicleType() + " -  MSRP: " + vehicle.getPrice());
    } 
  }

  public void processGetByColorRequest() {
    System.out.print("What color vehicle would you like? \n"); 
    String color = scanner.nextLine().trim();
    // makeModel = makeModel.equalsIgnoresCase(makeModel).trim();
    int matchedVehicles = 0; 
    
    ArrayList<Vehicle> vehiclesArr = dealership.getVehiclesByColor(color);
    
    System.out.println("We currently have " + vehiclesArr.size() + " vehicles matching that color. \n");
      // for loop for one vehicle in the array of vehicles
    for (Vehicle vehicle : vehiclesArr) {
      System.out.println("Vin: " + vehicle.getVin() + " - " + vehicle.getMake() + " " + vehicle.getModel() + " " + vehicle.getYear() + " " + vehicle.getColor() + " - Odometer: " + vehicle.getOdometer() + " " + vehicle.getVehicleType() + " -  MSRP: " + vehicle.getPrice());
    } 
  }

  public void processGetByMilageRequest() {
    System.out.print("What is the maximum mileage? \n"); 
    System.out.print("Maximum milage: ");
    int max = scanner.nextInt();

    // data type is not required when passing params
    ArrayList<Vehicle> vehiclesArr = dealership.getVehiclesByMilage(max);

    // move to a display all method
    System.out.println("We currently have " + vehiclesArr.size() + " vehicles \n");

     // for loop for one vehicle in the array of vehicles
    for (Vehicle vehicle : vehiclesArr) {
      System.out.println("Vin: " + vehicle.getVin() + " - " + vehicle.getMake() + " " + vehicle.getModel() + " " + vehicle.getYear() + " " + vehicle.getColor() + " - Odometer: " + vehicle.getOdometer() + " " + vehicle.getVehicleType() + " -  MSRP: " + vehicle.getPrice());
    } 
  }

  public void processGetAllVehicleRequest() {
    displayAllVehicles();
  }

  public void processGetByTypeRequest(){
    System.out.print("What type of vehicle would you like? \n"); 
    String vehicleType = scanner.nextLine().trim();
    // makeModel = makeModel.equalsIgnoresCase(makeModel).trim();
    int matchedVehicles = 0;
    
    ArrayList<Vehicle> vehiclesArr = dealership.getVehiclesByType(vehicleType);
    
    System.out.println("We currently have " + vehiclesArr.size() + " vehicles matching type. \n");
        // for loop for one vehicle in the array of vehicles
    for (Vehicle vehicle : vehiclesArr) {
      System.out.println("Vin: " + vehicle.getVin() + " - " + vehicle.getMake() + " " + vehicle.getModel() + " " + vehicle.getYear() + " " + vehicle.getColor() + " - Odometer: " + vehicle.getOdometer() + " " + vehicle.getVehicleType() + " -  MSRP: " + vehicle.getPrice());
    } 
  }

  public void processAddVehicleRequest() {
    // passes in the private init
    init();

    // all prompts to trigger vehicle info
    System.out.print("Please Enter vin: ");
    int vin = scanner.nextInt();
    System.out.print("Please Enter Year: ");
    int year = scanner.nextInt();
    scanner.nextLine();
    System.out.print("Please Enter Make: ");
    String make = scanner.nextLine();
    System.out.print("Please Enter Model: ");
    String model = scanner.nextLine();
    System.out.print("Please Enter Vehicle Type: ");
    String vehicleType = scanner.nextLine();
    System.out.print("Please Enter Color : ");
    String color = scanner.nextLine();
    System.out.print("Please Enter Odometer : ");
    int odometer = scanner.nextInt();
    System.out.print("Please Enter Price/MSRP : ");
    double price = scanner.nextDouble();

    // passes info as new vehicle based on constructor
    Vehicle vehicle = new Vehicle(vin, year, make, model, vehicleType, color, odometer, price);
    dealership.addVehicle(vehicle);
    System.out.println("The vehicle has been added to the Dealership : ");
    System.out.println(vehicle);

    // this has to call the method and writes to the file manager 
    dealershipFileMgr.saveDealership(dealership);
  }

  public void processRemoveRequest() {
    System.out.print("Please enter the vin number of the vehicle you would like to remove: ");
    int vin = scanner.nextInt();
    // scans and removes only the matching vin
   dealership.removeVehicle(vin);

          // move to a display all method
    System.out.println("The vehicle matching this vin which was removed \n");

    // this has to call the method and writes to the file manager 
    dealershipFileMgr.saveDealership(dealership);
  }


  public void SearchByTerm() {
    System.out.print("What would you like to search by? \n"); 
    String inputString  = scanner.nextLine().trim().toLowerCase();
    
    ArrayList<Vehicle> vehiclesArr = dealership.getVehicleBySearchTerm(inputString);
  
    System.out.println("We currently have " + vehiclesArr.size() + " vehicles matching search parameter. \n");
        // for loop for one vehicle in the array of vehicles
      for (Vehicle vehicle : vehiclesArr) {
        System.out.println("Vin: " + vehicle.getVin() + " - " + vehicle.getMake() + " " + vehicle.getModel() + " " + vehicle.getYear() + " " + vehicle.getColor() + " - Odometer: " + vehicle.getOdometer() + " " + vehicle.getVehicleType() + " -  MSRP: " + vehicle.getPrice());
      }    
  }

  public void SortByYear() {
    
    // ArrayList<Vehicle> vehiclesArr = dealership.getAllVehicles();

    // Arrays.sort(tokens);

    // Arrays.sort(tokens, Collections.reverseOrder());
  
    // System.out.println("We currently have " + vehiclesArr.size() + " vehicles matching search parameter. \n");
    //     // for loop for one vehicle in the array of vehicles
    //   for (Vehicle vehicle : vehiclesArr) {
    //     System.out.println("Vin: " + vehicle.getVin() + " - " + vehicle.getMake() + " " + vehicle.getModel() + " " + vehicle.getYear() + " " + vehicle.getColor() + " - Odometer: " + vehicle.getOdometer() + " " + vehicle.getVehicleType() + " -  MSRP: " + vehicle.getPrice());
    //   }    
  }

}