import java.util.*;

public class Program {
  public static void main(String [] args) {      
    UserInterface cli = new UserInterface();
    cli.display();

  }
}