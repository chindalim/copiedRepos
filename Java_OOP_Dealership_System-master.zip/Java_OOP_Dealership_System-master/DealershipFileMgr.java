import java.io.*;
import java.util.*;

public class DealershipFileMgr {

  public Dealership getDealership() {

    Dealership dealership = null;

    try {
      // inputs the file from the dealership database.txt file
      FileInputStream fileIS = new FileInputStream("db_dealership.txt");
      
      // scanning in lines
      Scanner scanner = new Scanner(fileIS);

      // reading next line
      String line = scanner.nextLine();
      String[] tokens = line.split("\\|");
      // creates and places the dealership into an object - Dealership(0- String name, 1- String address, 2- String phone)
      dealership = new Dealership(tokens[0], tokens[1], tokens[2]);
 
      // while loop - while there is something in the next line it's going to create a new vehicle
      while(scanner.hasNextLine()) {
      line = scanner.nextLine();
      tokens = line.split("\\|");
       // Vehicle(int vin, int year, String make, String model, String vehicleType, String color, int odometer, double price)
      // places the values within the pipes into an array
      Vehicle vehicle = new Vehicle( Integer.parseInt(tokens[0]), Integer.parseInt(tokens[1]), tokens[2], tokens[3], tokens[4], tokens[5], Integer.parseInt(tokens[6]), Double.parseDouble(tokens[7]));

      // adds the vehicle
      dealership.addVehicle(vehicle);
      }
      // // debugging test
      // System.out.println("Test inside try block");
      scanner.close();
    } catch (IOException e) {
      //TODO: handle exception
      System.out.print("***Error: Exception caught in Catch block. Cannot load or display vehicles \n***");
    }

    return dealership;
  }


  public Dealership saveDealership(Dealership dealership) {
    try {
    // writing to the file manger
    FileWriter writer = new FileWriter("db_dealership.txt");
    // formats the new line to send to the file
    String line = String.format("%s|%s|%s", dealership.getName(), dealership.getAddress(), dealership.getPhone());
    // writing all of the dealerships info to the db_dealership file
    writer.write(line);

    // write all the vehicles into the file - calling on the dealership.java file to pull in the getAllVehicles method
      ArrayList<Vehicle> uiView = dealership.getAllVehicles();
      // for loop like with Angular
      for (Vehicle oneVehicle : uiView) {
        // print format to the txt file
      line = String.format("\n%d|%d|%s|%s|%s|%s|%d|%.2f",oneVehicle.getVin(), oneVehicle.getYear(), oneVehicle.getMake(), oneVehicle.getModel(), oneVehicle.getVehicleType(), oneVehicle.getColor(),  oneVehicle.getOdometer(), oneVehicle.getPrice());        // writes the line to the txt file
        writer.write(line);
      }
    writer.close();
      // debugging test
          // move to a display all method
    System.out.println("Success process completed. \n");
      } catch (Exception e) {
      //TODO: handle exception
    System.out.print("***Error: Exception caught in Catch block. Cannot add or load vehicles into DB file \n***");
    e.printStackTrace();
    }
    // since it's not void it has to return something in this case a dealership
    return dealership;
  }

}


// Phase 2
// The next piece of code you will build is the "persistence layer". That is, the class that understands how to read the dealership file and convert the text into a fully loaded Dealership object. It also knows how to take the data from a Dealership object and re-write the file.