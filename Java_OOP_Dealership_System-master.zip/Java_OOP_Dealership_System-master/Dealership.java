import java.util.*;

public class Dealership {
  private String name, address, phone;
  
  // creating a new Array 
  private ArrayList<Vehicle> vehiclesArr;

  public Dealership( String name, String address, String phone) {
    this.name = name;
    this.address = address;
    this.phone = phone;

    // assigning vArr to Vehicle Array List added and passed in the constructor
    vehiclesArr = new ArrayList<Vehicle>();
  }

  // getters

  public String getName() {
    return name;
  }

  public String getAddress() {
    return address;
  }

  public String getPhone() {
    return phone;
  }


  // setters

  public void setName(String name) {
    this.name = name;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }

  // start of all methods for dealership

  // method to return all vehicles 
  public ArrayList<Vehicle> getAllVehicles() {
    return vehiclesArr;
  }

  // void methods do not return anything
  // data type is required when catching arguments
  public ArrayList<Vehicle> getVehiclesByPrice(double min, double max) {
    // add notes
    ArrayList<Vehicle> matchingV = new ArrayList<Vehicle>();
    for (Vehicle v : vehiclesArr) {
      if (v.getPrice() >= min && v.getPrice() <= max) {
        matchingV.add(v);
      }
    }
    return matchingV;
  }

  // finish method
  public ArrayList<Vehicle> getVehiclesByMakeModel(String make, String model) {
     ArrayList<Vehicle> matchingV = new ArrayList<Vehicle>();
    for (Vehicle v : vehiclesArr) {
      if (v.getMake().toLowerCase().contains(make) && v.getModel().toLowerCase().contains(model)) {
        matchingV.add(v);
      }
    }
    return matchingV;
  }

  public ArrayList<Vehicle> getVehiclesByYear(int min, int max) {
    ArrayList<Vehicle> matchingV = new ArrayList<Vehicle>();
    for (Vehicle v : vehiclesArr) {
      if (v.getYear() >= min && v.getYear() <= max) {
        matchingV.add(v);
      }
    }
    return matchingV;  
  }

  public ArrayList<Vehicle> getVehiclesByColor(String color) {
    ArrayList<Vehicle> matchingV = new ArrayList<Vehicle>();
    for (Vehicle v : vehiclesArr) {
      if (v.getColor().toLowerCase().contains(color)) {
        matchingV.add(v);
      }
    }
    return matchingV;  
  }

  public ArrayList<Vehicle>  getVehiclesByMilage(int max) {
    // add notes
    ArrayList<Vehicle> matchingV = new ArrayList<Vehicle>();
    for (Vehicle v : vehiclesArr) {
      if (v.getOdometer() <= max) {
        matchingV.add(v);
      }
    }
    return matchingV;
  }

  public ArrayList<Vehicle> getVehiclesByType(String vehicleType) {
    ArrayList<Vehicle> matchingV = new ArrayList<Vehicle>();
    for (Vehicle v : vehiclesArr) {
      if (v.getVehicleType().toLowerCase().contains(vehicleType)) {
        matchingV.add(v);
      }
    }
    return matchingV;  
  }

  public ArrayList<Vehicle> addVehicle(Vehicle vehicle) {
   vehiclesArr.add(vehicle);
   return null;
  }

  public void removeVehicle(int vin) {
    //  for loop below allows for the index of to be reset
    for (int i = 0; i < vehiclesArr.size(); i++) {
      // finds the vehicle by vin
      if (vehiclesArr.get(i).getVin() == vin) {
        // removes from the array list
        vehiclesArr.remove(i);
        break;
      }
    }
  }

  public ArrayList<Vehicle> getVehicleBySearchTerm(String inputString) {
    ArrayList<Vehicle> matchingV = new ArrayList<Vehicle>();
    for (Vehicle v : vehiclesArr) {
      if (
      v.getColor().toLowerCase().contains(inputString) ||
      v.getMake().toLowerCase().contains(inputString) ||
      v.getModel().toLowerCase().contains(inputString) ||
      Integer.toString(v.getYear()).contains(inputString) ||
      Integer.toString(v.getOdometer()).contains(inputString) ||
      Double.toString(v.getPrice()).contains(inputString)) {
        matchingV.add(v);
      }
    }
    return matchingV;  
  }
}

// dealership manages the data for the vehicle

