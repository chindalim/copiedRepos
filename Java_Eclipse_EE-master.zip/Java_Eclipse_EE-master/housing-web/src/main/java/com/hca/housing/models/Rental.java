package com.hca.housing.models;

public class Rental {

	private String typeOfUnit;
	private String address;
	private String zipCode;
	private int numBeds;
	private int numBaths;
	private double monthlyRent;
	private boolean petsAllowed;

	public Rental(String typeOfUnit, String address, String zipCode, int numBeds, int numBaths, double monthlyRent,
			boolean petsAllowed) {
		super();
		this.typeOfUnit = typeOfUnit;
		this.address = address;
		this.zipCode = zipCode;
		this.numBeds = numBeds;
		this.numBaths = numBaths;
		this.monthlyRent = monthlyRent;
		this.petsAllowed = petsAllowed;
	}

	public String getTypeOfUnit() {
		return typeOfUnit;
	}

	public void setTypeOfUnit(String typeOfUnit) {
		this.typeOfUnit = typeOfUnit;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public int getNumBeds() {
		return numBeds;
	}

	public void setNumBeds(int numBeds) {
		this.numBeds = numBeds;
	}

	public int getNumBaths() {
		return numBaths;
	}

	public void setNumBaths(int numBaths) {
		this.numBaths = numBaths;
	}

	public double getMonthlyRent() {
		return monthlyRent;
	}

	public void setMonthlyRent(double monthlyRent) {
		this.monthlyRent = monthlyRent;
	}

	public boolean isPetsAllowed() {
		return petsAllowed;
	}

	public void setPetsAllowed(boolean petsAllowed) {
		this.petsAllowed = petsAllowed;
	}

}
