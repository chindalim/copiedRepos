package com.hca.housing.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hca.housing.models.HousingCenter;
import com.hca.housing.models.Rental;

/**
 * Servlet implementation class RentalServletByPets
 */
@WebServlet(description = "seaching for rentals by pets only", urlPatterns = { "/petsallowed" })
public class RentalServletByPets extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RentalServletByPets() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// TODO Auto-generated method stub
//		PrintWriter writer = response.getWriter();
		response.setContentType("text/html");
		List<Rental> petApproved;
//
//		String uri = request.getRequestURI();
////		String[] tokens = uri.split("/");
//		if (tokens.length >= 2) {
//			String type = tokens[1].toLowerCase();

//		return all rentals
			HousingCenter housingCenter = new HousingCenter();

//		return the is pets allowed = true
			petApproved = housingCenter.getPetsAllowed();
			request.setAttribute("pets-approved", petApproved);

			RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/pets.jsp");
			dispatcher.forward(request, response);

		}
	}
