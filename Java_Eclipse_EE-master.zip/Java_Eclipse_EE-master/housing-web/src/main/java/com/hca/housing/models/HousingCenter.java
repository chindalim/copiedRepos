package com.hca.housing.models;

import java.util.*;
import java.util.stream.*;

public class HousingCenter {
	ArrayList<Rental> list = new ArrayList<Rental>();

	public HousingCenter() {
		list.add(new Rental("APT", "111 Main #1", "76112", 2, 1, 1200.00, false));
		list.add(new Rental("HOUSE", "301 Duchess", "76113", 4, 2, 3200.00, true));
		list.add(new Rental("APT", "111 Main #2", "76112", 3, 2, 1575.00, false));
		list.add(new Rental("APT", "111 Main #6", "76112", 2, 1, 1500.00, false));
		list.add(new Rental("HOUSE", "218 Regent", "76113", 3, 1, 2100.00, false));
		list.add(new Rental("HOUSE", "221 Galahad", "76115", 4, 2, 2600.00, true));
		list.add(new Rental("APT", "222 Main #2", "76101", 2, 2, 1700.00, false));
		list.add(new Rental("HOUSE", "331 Princess", "76112", 3, 2, 2200.00, false));
		list.add(new Rental("APT", "333 Main #3", "76122", 3, 1, 1500.00, true));
	}

//	calls from array list above
	public List<Rental> getRentals() {
		return list;
	}

//	gets rentals within a min and max perameter List is the interface version of the array list
	public List<Rental> getRentalsByPrice(double min, double max) {
//		lamda expression
		List<Rental> matchingRentals = list.stream()
				.filter(rental -> rental.getMonthlyRent() >= min && rental.getMonthlyRent() <= max)
				.collect(Collectors.toList());

		return matchingRentals;
	}
	
//	gets rentals within a min and max perameter List is the interface version of the array list
	public List<Rental> getPetsAllowed() {
//		lamda expression
		List<Rental> matchingRentals = list.stream()
				.filter(rental -> rental.isPetsAllowed() == true)
				.collect(Collectors.toList());

		return matchingRentals;
	}
	
}