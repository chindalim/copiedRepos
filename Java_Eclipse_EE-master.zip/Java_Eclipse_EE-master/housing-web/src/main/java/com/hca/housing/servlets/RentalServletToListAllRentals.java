package com.hca.housing.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hca.housing.models.HousingCenter;
import com.hca.housing.models.Rental;

/**
 * Servlet implementation class RentalServletToListAllRentals
 */
@WebServlet("/allrentals")
public class RentalServletToListAllRentals extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RentalServletToListAllRentals() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter writer = response.getWriter();
		response.setContentType("text/html");

		HousingCenter housingCenter = new HousingCenter();

		List<Rental> rentals = housingCenter.getRentals();
		writer.println("<body><html");
		writer.println("<h2 class='m-5'>  All Available Rentals </h2>");

		if (rentals.size() == 0) {
			writer.println("No rentals found.");

		} else {
			writer.println("<table class='table table-striped'><thead><tr>");
			writer.println(
					"<th>Type</th><th>Address</th><th>Zip</th><th>Beds</th><th>Baths</th><th>Monthly Rent</th><th>Pets Allowed</th>");
			writer.println("</tr></thead>");
			writer.println("<tbody>");

			for (Rental rental : rentals) {
				writer.print("<tr>");
				writer.printf("<td>%s</td>", rental.getTypeOfUnit());
				writer.printf("<td>%s</td>", rental.getAddress());
				writer.printf("<td>%s</td>", rental.getZipCode());
				writer.printf("<td>%d</td>", rental.getNumBeds());
				writer.printf("<td>%d</td>", rental.getNumBaths());
				writer.printf("<td>$%.2f</td>", rental.getMonthlyRent());
				writer.printf("<td>%s</td>", rental.isPetsAllowed() ? "Yes" : "No");
				writer.print("</tr>");
			}

			writer.println("</tbody></table>");
		}

		writer.println("</body></html");

	}

}
