package com.hca.housing.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hca.housing.models.HousingCenter;
import com.hca.housing.models.Rental;

/**
 * Servlet implementation class RentalServletSelectByPrice
 */
@WebServlet("/byprice")
public class RentalServletSelectByPrice extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RentalServletSelectByPrice() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter writer = response.getWriter();
//		writer.append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");

		Map<String, String[]> queryStringMap = request.getParameterMap();

		double min = 0;
		double max = 0;

//		pulls in the location of the min and max from the index page and passes as the query string parameter
		min = Double.parseDouble(queryStringMap.get("min")[0]);
		max = Double.parseDouble(queryStringMap.get("max")[0]);

		HousingCenter housing = new HousingCenter();
		List<Rental> rentals = housing.getRentalsByPrice(min, max);

		if (rentals.size() == 0) {
			writer.println("We're sorry but no rentals were found within your price range.");
		} else {
			writer.printf("<h2 class='text-center pb-5'>Rentals Between %.2f & %.2f</h2>\n", min, max);
			writer.println(
					"<th>Type</th><th>Address</th><th>Zip</th><th>Beds</th><th>Baths</th><th>Monthly Rent</th><th>Pets Allowed</th>");
			writer.println("</tr></thead>");
			writer.println("<br>");
			writer.println("<tbody>");

			for (Rental rental : rentals) {
				writer.printf("<tr>");
				writer.printf("<td>%s</td>", rental.getTypeOfUnit());
				writer.printf("<td>%s</td>", rental.getAddress());
				writer.printf("<td>%s</td>", rental.getZipCode());
				writer.printf("<td>%d</td>", rental.getNumBeds());
				writer.printf("<td>%d</td>", rental.getNumBaths());
				writer.printf("<td>$%.2f</td>", rental.getMonthlyRent());
				writer.printf("<td>%s</td>", rental.isPetsAllowed() ? "Yes" : "No");
				writer.printf("</tr>");
				writer.println("<br>");
			}
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
