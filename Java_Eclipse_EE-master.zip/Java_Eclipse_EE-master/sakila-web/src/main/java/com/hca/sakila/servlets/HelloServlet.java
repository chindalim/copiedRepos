package com.hca.sakila.servlets;

import java.io.IOException;
import java.io.PrintWriter;

// auto imports for the doGet method below when the refactor was completed.
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HelloServlet & builds class
 */
@WebServlet(description = "A hello world servlet", urlPatterns = { "/hello" })
public class HelloServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */

//	Inherits all from from HTTPServlet
	public HelloServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub generated from the refactor tab - highlight
		// the item and hit refactor and then go to extract local variable.
		PrintWriter writer = response.getWriter();
		response.setContentType("text/html");
//		writer.append("Served at: ").append(request.getContextPath());
		writer.println("<img src='images/hot-air-balloons.jpeg' alt='hot air balloon'>");
		writer.println("<h1>Hello World! I am a fire rabbit. </h1>");
		writer.println(
				"<h3> People born in 1987 year of the Rabbit are intelligent and skillful, and they can easily get 				succeed in every field. </h3>");
		writer.println(
				"<p>  Fire Rabbit in the Chinese zodiac applies to those born in 1927 and 1987. The Rabbit is the 				fourth animal in the 12-year cycle and is also given to those born in 1927, 1939, 1951, 1963, 				1975, 1987, 1999, 2011, 2023. Follow all our latest stories on the Chinese Zodiac.  </p>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
