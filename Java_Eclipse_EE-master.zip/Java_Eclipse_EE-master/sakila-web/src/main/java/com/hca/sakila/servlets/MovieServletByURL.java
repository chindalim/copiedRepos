package com.hca.sakila.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hca.sakila.models.MovieLibrary;

/**
 * Servlet implementation class MovieServletByURL URL Pattern should be
 * /sakila-web/movies/bygenre/{genre} annotations start with @ signs and do not
 * need a semicolon
 */
@WebServlet("/movies/bygenre/*")
public class MovieServletByURL extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MovieServletByURL() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// TODO Auto-generated method stub
		PrintWriter writer = response.getWriter();

//		writer.append("Served at: ").append(request.getContextPath());		
		response.setContentType("text/html");

		writer.println("<h3>URI request is working.</h3>");

		String uri = request.getRequestURI();

		System.out.println("*********" + uri);

//		example - http://localhost:8080/sakila-web/movies/bygenre/comedy
		String[] tokens = uri.split("/");
		if (tokens.length >= 5) {
			String genre = tokens[4].toLowerCase();
			MovieLibrary movieLibrary = new MovieLibrary();
//			find move in the specified genre - pulling movies from the MovieLibrary.java class file
			String[] matchingMovies = movieLibrary.getMovies(genre);

			writer.println("<h1>Selected genre is " + genre + ".</h1>");
			writer.println("<h5>We suggest the following movies in this genre :</h5>");
			writer.println("ul");
			for (String movie : matchingMovies) {
				writer.println("<li>" + movie + "</li>");
			}
			writer.println("/ul");
		} else {
			writer.println("Error: A genre was not specified");
		}
	}

}
