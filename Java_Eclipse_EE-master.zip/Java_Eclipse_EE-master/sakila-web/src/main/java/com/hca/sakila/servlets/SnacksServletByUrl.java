package com.hca.sakila.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hca.sakila.models.Snack;
import com.hca.sakila.models.SnackCounter;

/**
 * Servlet implementation class SnacksServletByUrl
 */
@WebServlet(description = "Get Snacks based on URL", urlPatterns = { "/snacks/type/*" })
public class SnacksServletByUrl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SnacksServletByUrl() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter writer = response.getWriter();
//		writer.append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");

		String uri = request.getRequestURI();
		String[] tokens = uri.split("/");
		if (tokens.length >= 5) {
			String snackType = tokens[4].toLowerCase();

			SnackCounter snackCounter = new SnackCounter();
			Snack[] matchingSnacks = snackCounter.getSnacksByCategory(snackType);
			
//			request to jsp server and adds the data to the request scope
			request.setAttribute("snack-type", snackType);
			request.setAttribute("matching-snacks", matchingSnacks);
		} else {
//			returns no snack type message if none are found
			request.setAttribute("snack type is", "missing");
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/snacks.jsp");
		dispatcher.forward(request, response);
//			new version the servlet will not geenerate html --- it will ask a jsp to do it
			
			
// in this version the servlet generated html with a table tag
//			writer.println("<h3>Your matching snacks for " + snackType + " : are below </h3>");
//
//			writer.println("<table>");
//			writer.println("<thead>");
//			writer.println("<tr>");
//			writer.println("<td> Product Name: </td>");
//			writer.println("<td>Product Price: </td>");
//			writer.println("</tr>");
//			writer.println("</thead>");
//			writer.println("<tbody>");
//			for (Snack snack : matchingSnacks) {
//				writer.println("<tr>");
//				writer.println("<td>" + snack.getProductName() + "</td>");
//				writer.printf("<td>" + String.format("$ %.2f", snack.getPrice()) + "</td>");
//				writer.println("</tr>");
//			}
//			writer.println("</tbody>");
//			writer.println("</table>");

//			writer.println("<ul>");

//			updated to an object of snacks
//			for (Snack snack : matchingSnacks) {
////				updated to the snack class object
//				writer.println("<li>" + snack.getProductName() + "$ <em>" + snack.getPrice() + " </em></li>");
//				
//				writer.printf(snackType, matchingSnacks);
//				writer.printf("<li>" + snack.getProductName() + String.format("($%.2f)", snack.getPrice()) + " </em></li>");

//		}
//			writer.println("</ul>");
	}
}

//	protected String[] getSnacks(String snackType) {
////	the movies would not be hard coded in example below and will come from an API or database
//		HashMap<String, String[]> mySnacks = new HashMap<String, String[]>();
//
//		mySnacks.put("salty", new String[] { "trail mix", "chips", "pretzel", "popcorn" });
//		mySnacks.put("sweet", new String[] { "soda", "gummy worms", "ice cream", "skittles" });
//		mySnacks.put("sour", new String[] { "shock tarts", "sour gummy worms" });
//		mySnacks.put("chocolate", new String[] { "reese", "twix", "kit kat" });
//
//		return mySnacks.get(snackType);
//	}

//}
