package com.hca.sakila.models;

import java.util.HashMap;

public class SnackCounter {

	private HashMap<String, Snack[]> snacks = new HashMap<String, Snack[]>();

	public SnackCounter() {
		super();

//				mySnacks.put("salty", new String[] { "trail mix", "chips", "pretzel", "popcorn" });
//		mySnacks.put("sweet", new String[] { "soda", "gummy worms", "ice cream", "skittles" });
//		mySnacks.put("sour", new String[] { "shock tarts", "sour gummy worms" });
//		mySnacks.put("chocolate", new String[] { "reese", "twix", "kit kat" });

		snacks.put("sweet", new Snack[] { new Snack("Pepsi", 5.99f), new Snack("Water", 6.99f),
				new Snack("Lemonade", 5.99f), new Snack("Coke", 5.99f), new Snack("Ginger Ale", 5.99f) });

		snacks.put("chocolate", new Snack[] { new Snack("reese", 5.99f), new Snack("twix", 6.99f),
				new Snack("kit kat", 5.99f), new Snack("mochi", 5.99f), new Snack("matcha twix", 5.99f) });
		
		snacks.put("salty", new Snack[] { new Snack("trail mix", 5.99f), new Snack("pretzel", 6.99f),
				new Snack("pretzel", 5.99f), new Snack("popcorn", 5.99f), new Snack("chips", 5.99f) });
		
		
		snacks.put("sour", new Snack[] { new Snack("shock tarts", 5.99f), new Snack("sour gummy worms", 6.99f),
				new Snack("war heads", 5.99f), new Snack("now and laters", 5.99f), new Snack("sour gummy bears", 5.99f) });
	}

	public Snack[] getSnacksByCategory(String category) {
		return snacks.get(category);

	}

}
