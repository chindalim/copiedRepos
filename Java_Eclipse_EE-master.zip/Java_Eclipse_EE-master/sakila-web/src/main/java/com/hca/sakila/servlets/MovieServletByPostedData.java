package com.hca.sakila.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hca.sakila.models.MovieLibrary;

/**
 * Servlet implementation class MovieServletByPostedData
 */
@WebServlet(description = "Find Movie Data By Genre From Servlet", urlPatterns = { "/movies/postrequest" })
public class MovieServletByPostedData extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MovieServletByPostedData() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter writer = response.getWriter();
		response.setContentType("text/html");

		// get the query string parameters into a collection
		// of key/value pairs
		Map<String, String[]> queryStringMap = request.getParameterMap();

		if (!queryStringMap.containsKey("genre")) {
			writer.println("<h4>It seems there are no genres that you are interested in</h4>");
			return;
		}

		// gets all of the keys matching the value "genre"
		String[] allGenresPassedToServlet = queryStringMap.get("genre");

		// if the key "genre" is found loops through the array

		for (String genre : allGenresPassedToServlet) {
//			if(genre.trim().equals("") ) {
//				
//			}
			writer.println("<h3>" + genre + "</h3>");

			MovieLibrary movieLibrary = new MovieLibrary();
//				find move in the specified genre - pulling movies from the MovieLibrary.java class file
			String[] matchingMovies = movieLibrary.getMovies(genre);

//					?generate the list of all movies
			writer.println("<ul>");
			for (String movie : matchingMovies) {
				writer.println("<li>" + movie + "</li>");
			}
			writer.println("<ul>");
		}
	

	}

}
