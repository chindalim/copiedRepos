package com.hca.sakila.models;

import java.util.HashMap;

public class MovieLibrary {

	public String[] getMovies(String genre) {

//		the movies would not be hard coded in example below and will come from an API or database
		HashMap<String, String[]> myMovies = new HashMap<String, String[]>();

		myMovies.put("comedy", new String[] { "The Other Guys", "Big Daddy", "Just Go With It", "50 First Dates" });
		myMovies.put("action", new String[] { "Matrix", "Ong Bok", "James Bond", "Master Ip" });
		myMovies.put("heist", new String[] { "Oceans 11", "Oceans 12", "Just Go With It", "50 First Dates" });
		myMovies.put("hero", new String[] { "Black Wigdow", "Spiderman", "Ant Man", "Captain America" });

		return myMovies.get(genre);
	}
}
