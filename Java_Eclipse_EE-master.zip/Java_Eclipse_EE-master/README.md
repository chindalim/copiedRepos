<h1 align="center">ECLIPSE WORKSPACE EE</h1>

## Table Of Contents

- dealership-web
- housing-web
- Sakila-web
- Servers

## Overview & Objectives

** To view java program files please view the .java file. **

#### dealership-web

The dealership web started as a console based program reading from a text file. It evolved to a web based app reading files from an SQL database.

#### housing-web

Web based app using servlets, models and JSPs.

#### sakila-web

App used for testing sql database queries.
