package com.hca.dealership.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hca.dealership.models.Dealership;
import com.hca.dealership.models.DealershipFileMgr;
import com.hca.dealership.models.Vehicle;

/**
 * Servlet implementation class SearchByPriceServlet
 */
@WebServlet("/byprice")
public class SearchByPriceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SearchByPriceServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		ArrayList<Vehicle> vehiclebyprice;

// returns the dealership
		DealershipFileMgr dealershipFileMgr = new DealershipFileMgr();
//		return all vehicles
		Dealership dealership = dealershipFileMgr.getDealership();

		Map<String, String[]> queryStringMap = request.getParameterMap();

		double min = 0;
		double max = 0;

//		pulls in the location of the min and max from the index page and passes as the query string parameter
		min = Double.parseDouble(queryStringMap.get("min")[0]);
		max = Double.parseDouble(queryStringMap.get("max")[0]);

		vehiclebyprice = dealership.getVehiclesByPrice(min, max);
		request.setAttribute("vehicle-by-price", vehiclebyprice);

		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/display-vehicle-by-price.jsp");
		dispatcher.forward(request, response);
	}

}
