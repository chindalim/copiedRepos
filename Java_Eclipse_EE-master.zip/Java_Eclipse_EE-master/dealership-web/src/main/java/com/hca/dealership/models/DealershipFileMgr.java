package com.hca.dealership.models;

import java.io.*;
import java.sql.*;
import java.util.*;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

public class DealershipFileMgr {

	private MysqlDataSource mysqlDS;

	// creating connection to sql data
	public DealershipFileMgr() {
		mysqlDS = new MysqlDataSource();
		mysqlDS.setServerName("localhost");
		mysqlDS.setPort(3306);
		mysqlDS.setUser("root");
		mysqlDS.setPassword("climHIG");
		mysqlDS.setDatabaseName("dealership");
	}

	public Dealership getDealership() {

		Dealership dealership = null;

		try (
				// use the driver to create a connection
				Connection connection = mysqlDS.getConnection();
				// Creating a prepared statement and finding all dealerships (in this case 1)
				PreparedStatement preparedStatement = connection
						.prepareStatement("SELECT * FROM dealership_info WHERE dealership_id = 1");

				// executing the query
				ResultSet results = preparedStatement.executeQuery();) {
			//
			// // while loop - while there is something in the next line it's going to
			// create a
			// // new vehicle

			while (results.next()) {
				// getting all dealership info

				dealership = new Dealership(results.getString("name"), results.getString("address"),
						results.getString("phone"));
			}
			// // debugging test
			// System.out.println("Test inside try block");
		} catch (SQLException e1) {

			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try (
				// use the driver to create a connection
				Connection connection = mysqlDS.getConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement("SELECT * FROM vehicles WHERE sold = 0");
				// executing the query
				ResultSet results = preparedStatement.executeQuery();) {

			//
			// // while loop - while there is something in the next line it's going to
			// create a
			// // new vehicle
			while (results.next()) {

				// Vehicle(int vin, int year, String make, String model, String vehicleType,
				// String color, int odometer, double price)
				// places the values within the pipes into an array
				Vehicle vehicle = new Vehicle(results.getInt("vin"), results.getInt("year"), results.getString("make"),
						results.getString("model"), results.getString("type"), results.getString("color"),
						results.getInt("odometer"), results.getDouble("price"));

				// adds the vehicle
				dealership.addVehicle(vehicle);
			}
			// // debugging test
			// System.out.println("Test inside try block");
		} catch (SQLException e1) {

			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return dealership;
	}

	public Dealership saveDealership(Dealership dealership) {
		try {
			// writing to the file manger
			FileWriter writer = new FileWriter(
					"C:\\Users\\CL89408\\Desktop\\HCA\\Java_OOP_Dealership_EclipseVersion\\dataFiles\\db_dealership.txt");
			// formats the new line to send to the file
			String line = String.format("%s|%s|%s", dealership.getName(), dealership.getAddress(),
					dealership.getPhone());
			// writing all of the dealerships info to the db_dealership file
			writer.write(line);

			// write all the vehicles into the file - calling on the dealership.java file to
			// pull in the getAllVehicles method
			ArrayList<Vehicle> uiView = dealership.getAllVehicles();
			// for loop like with Angular
			for (Vehicle oneVehicle : uiView) {
				// print format to the txt file
				line = String.format("\n%d|%d|%s|%s|%s|%s|%d|%.2f", oneVehicle.getVin(), oneVehicle.getYear(),
						oneVehicle.getMake(), oneVehicle.getModel(), oneVehicle.getVehicleType(), oneVehicle.getColor(),
						oneVehicle.getOdometer(), oneVehicle.getPrice()); // writes the line to the txt file
				writer.write(line);
			}
			writer.close();
			// debugging test
			// move to a display all method
			System.out.println("Success process completed. \n");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.print(
					"***Error: Exception caught in Catch block for saveDealership in Dealership File Mgr. Cannot add or load vehicles into DB file \n***");
			e.printStackTrace();
		}
		// since it's not void it has to return something in this case a dealership
		return dealership;
	}

	public Dealership leasedAndSoldVehicles(Dealership dealership) {
		try {
			// writing to the file manger
			FileWriter writer = new FileWriter(
					"C:\\Users\\CL89408\\Desktop\\HCA\\Java_OOP_Dealership_EclipseVersion\\dataFiles\\db_leasedAndSoldVehicles.txt");
			// formats the new line to send to the file
			String line = String.format("%s|%s|%s", dealership.getName(), dealership.getAddress(),
					dealership.getPhone());
			// writing all of the dealerships info to the db_dealership file
			writer.write(line);

			// write all the vehicles into the file - calling on the dealership.java file to
			// pull in the getAllVehicles method
			ArrayList<Vehicle> uiView = dealership.getAllVehicles();
			// for loop like with Angular
			for (Vehicle oneVehicle : uiView) {
				// print format to the txt file
				line = String.format("\n%d|%d|%s|%s|%s|%s|%d|%.2f", oneVehicle.getVin(), oneVehicle.getYear(),
						oneVehicle.getMake(), oneVehicle.getModel(), oneVehicle.getVehicleType(), oneVehicle.getColor(),
						oneVehicle.getOdometer(), oneVehicle.getPrice()); // writes the line to the txt file
				writer.write(line);
			}
			writer.close();
			// debugging test
			// move to a display all method
			System.out.println("Success process completed and added into database for leased and sold vehicles. \n");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.print(
					"***Error: Exception caught in Catch block for saveDealership in Dealership File Mgr. Cannot add or load vehicles into DB file \n***");
			e.printStackTrace();
		}
		// since it's not void it has to return something in this case a dealership
		return dealership;
	}

}

// Phase 2
// The next piece of code you will build is the "persistence layer". That is, the class that understands how to read the dealership file and convert the text into a fully loaded Dealership object. It also knows how to take the data from a Dealership object and re-write the file.