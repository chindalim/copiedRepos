<h2> Welcome to my Java Mini Project! 👋</h2>
An Object-Oriented Dealership System

***

## Table Of Contents

- [Table Of Contents](#table-of-contents)
  - [**How to Start and Stop program**](#how-to-start-and-stop-program)
  - [Overview & Objectives](#overview--objectives)
    - [Requirements](#requirements)
    - [Bonus Pages and Features Implemented](#bonus-pages-and-features-implemented)
- [View Admin Page](#view-admin-page) - WORK IN PROGRESS *** BONUS FEATURE
- [Features & Bonuses](#features--bonuses)
- [Learning Opportunities](#learning-opportunities)
- [Contributions and Contributing](#contributions-and-contributing)

***

### **How to Start and Stop program**

- How to Compile Java Program:
  - Javac *.java
    - this will compile all programs in the folder.
- How to Run Java Program:
  - Java Program (hit enter)
    - follow prompts
  - To stop program use Ctrl-C
  
***

### Overview & Objectives

Build a mini- console-based dealership app. This app would sit on the desk of a salesman or sales manager at a dealership. 
The entire system does not require password protection as it's assumed that the accessor is an approved user. 
The system focuses on OOP, reading and writing to files and persistance.

***

#### Requirements

- A simple UI showing the commands and actions below
- The ability to search for and view a list of vehicles
- Vehicles in the dealership will be persisted in a pipe-delimited file. 
- Changes to the dealership's inventory (when a vehicle is added or removed) will be updated file.
- Vehicle will hold information about a specific vehicle.
- Dealership will hold information about the dealership (name, address, …) and maintain an list of vehicles. Since it has the 	list of vehicles, it will also have the methods that search the list for matching vehicles as well as add/remove vehicles.
- DealershipFileManager will be responsible for reading the dealership file, parsing the data, and creating a Dealership object   full of vehicles from the file. It will also be responsible for saving a dealership and the vehicles back into the file in     the same pipe-delimited format.
- UserInterface will be responsible for all output to the screen, reading of user input, and "dispatching" of the commands to     the Dealership as needed. (ex: when the user selects "List all Vehicles", UserInterface would call the appropriate Dealership   method and then display the vehicles it returns.)
- Program will be responsible for starting the application via its main() method and then creating the user interface and         getting it started.

***

### Commands and Actions

| Command                  | Action                               |
| ----------------------- | -------------------------------------- |
| 1      | Find vehicles within a price range                     |
| 2  | Find vehicles by make / model     |
| 3 | Find vehicles by year range               |
| 4   | Find vehicles by color                         |
| 5   | Find vehicles by mileage range|
| 6   | Find vehicles by type (car, truck, SUV, van)           |
| 7   | List ALL vehicles                     |
| 8   | Add a vehicle     |
| 9   |Remove a vehicle                 |
| 10  | Search by term?                           |
| 11  | Sort by - *** pending bonus feature *** |
| 12                 | Sale a vehicle?            |
| 13      |  Lease a vehicle?                     |
| 99 | Quit                 |

***

## Admin Page

***PENDING / WORK IN PROGRESS***

## Features & Bonuses

Wild Card Search Feature
  
```java
public ArrayList<Vehicle> getVehicleBySearchTerm(String inputString) {
  ArrayList<Vehicle> matchingV = new ArrayList<Vehicle>();
	for (Vehicle v : vehiclesArr) {
  if (v.getColor().toLowerCase().contains(inputString)
    || v.getMake().toLowerCase().contains(inputString)
    || v.getModel().toLowerCase().contains(inputString)
    || Integer.toString(v.getYear()).contains(inputString)
    || Integer.toString(v.getOdometer()).contains(inputString)
    || Double.toString(v.getPrice()).contains(inputString)) 
    {
    matchingV.add(v);
    }
  }
  return matchingV;
}
```
</details>

***

## Learning Opportunities

<p>I need more time with UML diagrams, and with how data transfers and maps from one file to another.
 </p>
 
***

## Contributions and Contributing

&#128170; Katy L. 
&#128170; Keith
&#128170; Sasi
&#128170; Last but not lease DANA! Thank you for all you do.
 </p>

 <h3 align="left">Connect with me:</h3>
<p align="left">
<a href="https://codepen.io/chindalim" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/codepen.svg" alt="chindalim" height="30" width="40" /></a>
<a href="https://linkedin.com/in/chendar lim" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/linked-in-alt.svg" alt="chendar lim" height="30" width="40" /></a>
</p>

<h3>
Other Familiar Languages: 
<p><a href="https://developer.android.com" target="_blank"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/android/android-original-wordmark.svg" alt="android" width="40" height="40"/> </a> 
<a href="https://www.mongodb.com/" target="_blank"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mongodb/mongodb-original-wordmark.svg" alt="mongodb" width="40" height="40"/><a href="https://www.python.org" target="_blank"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="python" width="40" height="40"/> </a> <a href="https://reactjs.org/" target="_blank"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/react/react-original-wordmark.svg" alt="react" width="40" height="40"/> </a> <a href="https://reactnative.dev/" target="_blank"> <img src="https://reactnative.dev/img/header_logo.svg" alt="reactnative" width="40" height="40"/> </a> <a href="https://redux.js.org" target="_blank"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/redux/redux-original.svg" alt="redux" width="40" height="40"/> </a> <a href="https://sass-lang.com" target="_blank"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/sass/sass-original.svg" alt="sass" width="40" height="40"/> </a> </a> 
</p>
</h3>
