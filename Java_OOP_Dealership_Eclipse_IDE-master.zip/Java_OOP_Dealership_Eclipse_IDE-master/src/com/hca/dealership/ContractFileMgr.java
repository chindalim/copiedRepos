package com.hca.dealership;

import java.io.FileWriter;

public class ContractFileMgr extends Contract {

	private static Vehicle contractVehicle;

	public ContractFileMgr(String date, String customerName, String customerEmail, String vehicleSold,
			double totalPrice, double monthlyPayment) {
		super(vehicleSold, vehicleSold, vehicleSold, contractVehicle);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double getTotalPrice() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double getMonthlyPayment() {
		// TODO Auto-generated method stub
		return 0;
	}

//	to work on later
	public Contract getContract() {
		Contract contract = null;
		return contract;
	}

////	calls to the contract class 
//	public static Contract saveContract(Contract contract) {
//		String line = null;
//		try {
////			location of the file and where to write the new information to
//			FileWriter writer = new FileWriter(
//					"C:\\Users\\CL89408\\Desktop\\HCA\\Java_OOP_Dealership_EclipseVersion\\dataFiles\\db_contracts.txt");
////			Downcasting with java instanceof operator -  if else to check contact type need to use instance of to trigger the true or false.
//			if (contract instanceof SalesContract) {
////				format of the pipe deliminated values to the file
//				line = String.format("${member.name()|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s \n",
//						((SalesContract) contract).getSalesTax(), ((SalesContract) contract).getRecordingFee(),
//						((SalesContract) contract).getProcessingFee(), ((SalesContract) contract).getMonthlyPayment(),
//						((SalesContract) contract).isFinance(), contract.date, contract.customerName,
//						contract.customerEmail, contract.vehicleSold, contract.totalPrice);
//			}
//
//			if (contract instanceof LeaseContract) {
//				line = String.format("${member.name()|%s|%s|%s|%s|%s|%s|%s|%s \n",
//						((LeaseContract) contract).expectedEndingValue, ((LeaseContract) contract).leaseFee,
//						contract.monthlyPayment, contract.date, contract.customerName, contract.customerEmail,
//						contract.vehicleSold, contract.totalPrice);
//			}
//
////			writing just the line to the file
//			writer.write(line);
////			writer.close() is important to let the writer know it's done writing and needs to stop the process 
//			System.out.print("***Success: vehicle added to data file \n***");
//			writer.close();
//		} catch (Exception e) {
//			System.out.print(
//					"***Error: Exception caught in Catch block for saveDealership in Dealership File Mgr. Cannot add or load vehicles into DB file \n***");
//			e.printStackTrace();
//		}
//		return contract;
//
//	}

}
