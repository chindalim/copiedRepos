package com.hca.dealership;

public abstract class Contract {

	String date, customerName, customerEmail;
	Vehicle contractVehicle;
//	double totalPrice, monthlyPayment;

	/**
	 * @param date
	 * @param customerName
	 * @param customerEmail
	 * @param vehicleSold
	 * @param totalPrice     - these get calculated
	 * @param monthlyPayment
	 */
	public Contract(String date, String customerName, String customerEmail, Vehicle contractVehicle) {
		super();
		this.date = date;
		this.customerName = customerName;
		this.customerEmail = customerEmail;
		this.contractVehicle = contractVehicle;

	}

	/**
	 * @return the date
	 */
	public String getDate() {
		return date;
	}

	/**
	 * @param date the date to set
	 */
	public void setDate(String date) {
		this.date = date;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the customerEmail
	 */
	public String getCustomerEmail() {
		return customerEmail;
	}

	/**
	 * @param customerEmail the customerEmail to set
	 */
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	/**
	 * @return the vehicleSold
	 */
	public Vehicle getVehicleSold() {
		return contractVehicle;
	}

	/**
	 * @param vehicleSold the vehicleSold to set
	 */
	public void setVehicleSold(Vehicle vehicleSold) {
		this.contractVehicle = vehicleSold;
	}
	
	/**
	 * @return the vehicleSold
	 */
	public Vehicle getVehicleLeased() {
		return contractVehicle;
	}

	/**
	 * @param vehicleSold the vehicleSold to set
	 */
	public void setVehicleLeased(Vehicle vehicleLeased) {
		this.contractVehicle = vehicleLeased;
	}

	/**
	 * the totalPrice is an Abstract method which means it is incomplete
	 */
	public abstract double getTotalPrice();

	/**
	 * the monthlyPayment is an Abstract method which means it is incomplete
	 */
	public abstract double getMonthlyPayment();

}
