package com.hca.dealership;

import java.io.FileWriter;

public class ContractDataMgr {

	public ContractDataMgr() {
		// TODO Auto-generated constructor stub
	}

//	calls to the contract class 
	public static Contract saveContract(Contract contract) {
		String line = "";
		try {
//			location of the file and where to write the new information to
//			appending, adding true allows us to add instead of overwriting.
			FileWriter writer = new FileWriter(
					"C:\\Users\\CL89408\\Desktop\\HCA\\Java_OOP_Dealership_EclipseVersion\\dataFiles\\db_contracts.txt", true);
//			writer.write(line);
//			Downcasting with java instanceof operator -  if else to check contact type need to use instance of to trigger the true or false.
			if (contract instanceof SalesContract) {
				SalesContract salescontract = (SalesContract) contract;
//				format of the pipe deliminated values to the file
				line = String.format("\n%s|%s|%s|%s|%d|%s|%s|%s|%s|%d|%.2f|%.2f|%.2f|%.2f|%.2f|%s", "SALE",
						salescontract.date, salescontract.getCustomerName(), salescontract.getCustomerEmail(),
						salescontract.getVehicleSold().getYear(), salescontract.getVehicleSold().getMake(),
						salescontract.getVehicleSold().getModel(), salescontract.getVehicleSold().getVehicleType(),
						salescontract.getVehicleSold().getColor(), salescontract.getVehicleSold().getOdometer(),
						salescontract.getVehicleSold().getPrice(), salescontract.getSalesTax(),
						salescontract.getRecordingFee(), salescontract.getProcessingFee(),
						salescontract.getTotalPrice(), salescontract.isFinance());
				writer.write(line);
			}

			if (contract instanceof LeaseContract) {
				LeaseContract leaseContract = (LeaseContract) contract;
//				s f f f f s s s d f
				line = String.format("\n%s|%.2f|%.2f|%.2f|%.2f|%s|%s|%s|%d|%.2f", "LEASE", leaseContract.getLeaseFee(),
						leaseContract.getTotalPrice(), leaseContract.getExpectedEndingValue(),
						leaseContract.getMonthlyPayment(), leaseContract.date, leaseContract.customerName,
						leaseContract.customerEmail, leaseContract.getVehicleLeased().getYear(),
						leaseContract.contractVehicle.getPrice());
				writer.write(line);
			}
//			writer.close() is important to let the writer know it's done writing and needs to stop the process 
			System.out.print("***Success: vehicle added to data file \n***");
			writer.close();
		} catch (Exception e) {
			System.out.print(
					"***Error: Exception caught in Catch block for saveDealership in Dealership File Mgr. Cannot add or load vehicles into DB file \n***");
			e.printStackTrace();
		}
		return contract;

	}

}
