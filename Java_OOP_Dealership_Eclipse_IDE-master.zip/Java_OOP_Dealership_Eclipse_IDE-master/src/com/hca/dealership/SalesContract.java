package com.hca.dealership;

public class SalesContract extends Contract {

	private double salesTax = 0, recordingFee = 100, processingFee;
	private boolean finance;

	/**
	 * @param date
	 * @param customerName
	 * @param customerEmail
	 * @param v
	 * @param totalPrice
	 * @param monthlyPayment
	 * @param salesTax
	 * @param recordingFee
	 * @param processingFee
	 * @param monthlyPayment2
	 * @param fiance
	 */
	public SalesContract(String date, String customerName, String customerEmail, Vehicle v, boolean finance) {
		super(date, customerName, customerEmail, v);
		this.finance = finance;
		this.salesTax = v.getPrice() * .05;
		this.recordingFee = 100;
		this.processingFee = (v.getPrice() > 10000) ? 495 : 295;

	}

	/**
	 * @return the salesTax
	 */
	public double getSalesTax() {
		return salesTax;
	}

	public void setSalesTax(double salesTax) {
		this.salesTax = salesTax;
	}

	/**
	 * @return the recordingFee
	 */
	public double getRecordingFee() {
		return recordingFee;
	}

	public void setRecordingFee(double recordingFee) {
		this.recordingFee = recordingFee;
	}

	/**
	 * @return the processingFee
	 */
	public double getProcessingFee() {
		return processingFee;
	}

	public void setProcessingFee(double processingFee) {
		this.processingFee = processingFee;
	}

	/**
	 * @return the finance
	 */
	public boolean isFinance() {
		return finance;
	}

	public void setFinance(boolean finance) {
		this.finance = finance;
	}

	@Override
	public double getTotalPrice() {
		Vehicle v = getVehicleSold();
		double totalPrice = v.getPrice() + getSalesTax() + getProcessingFee() + getRecordingFee();
		return totalPrice;
	}

	/**
	 * @return the monthlyPayment
	 */
	@Override
	public double getMonthlyPayment() {
		double monthlyPayment = 0;
		Vehicle v = getVehicleSold();
		double totalCost = getTotalPrice();
		if (finance) {
			if (v.getPrice() >= 10000) {
				monthlyPayment = (totalCost * 4.25 / 1200) / (1 - Math.pow(1 + 4.25 / 1200, -48));
			} else {
				monthlyPayment = (totalCost * 4.25 / 1200) / (1 - Math.pow(1 + 4.25 / 1200, -24));
			}
		}
		return monthlyPayment;
	}

//	@Override
//	public String toString() {
//		return String.format("${member.name()|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|\\n", salesTax, recordingFee, processingFee,
//				monthlyPayment, finance, date, customerName, customerEmail, vehicleSold, totalPrice);
//	}

}
