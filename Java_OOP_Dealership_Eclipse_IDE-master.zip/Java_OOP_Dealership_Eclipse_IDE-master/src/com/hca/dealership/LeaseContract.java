package com.hca.dealership;

public class LeaseContract extends Contract {

	double expectedEndingValue, leaseFee = .07, monthlyPayment, procesingFee;

	/**
	 * @param date
	 * @param customerName
	 * @param customerEmail
	 * @param vehicleSold
	 * @param totalPrice
	 * @param monthlyPayment
	 * @param expectedEndingValue
	 * @param leaseFee
	 * @param monthlyPayment2
	 */
	public LeaseContract(String date, String customerName, String customerEmail, Vehicle v) {
		super(customerEmail, customerEmail, customerEmail, v);
		this.expectedEndingValue = v.getPrice() / 2;
		this.leaseFee = v.getPrice() * .07;
		this.procesingFee = (v.getPrice() > 10000) ? 495 : 295;
	}

	/**
	 * @return the expectedEndingValue
	 */
	public double getExpectedEndingValue() {
		return expectedEndingValue;
	}

	/**
	 * @return the leaseFee
	 */
	public double getLeaseFee() {
		return leaseFee;
	}

	/**
	 * @return the monthlyPayment
	 */
	@Override
	public double getMonthlyPayment() {
		double totalCost = getTotalPrice();

		if (totalCost >= 10000) {
			expectedEndingValue = (totalCost * 1.040) * leaseFee;
			monthlyPayment = expectedEndingValue / 36;
		}
		return monthlyPayment;

//		if (finance) {
//			if (v.getPrice() >= 10000) {
//				monthlyPayment = (totalCost * 4.25 / 1200) / (1 - Math.pow(1 + 4.25 / 1200, -48));
//			} else {
//				monthlyPayment = (totalCost * 4.25 / 1200) / (1 - Math.pow(1 + 4.25 / 1200, -24));
//			}
//		}
//		return monthlyPayment;
	}

	@Override
	public double getTotalPrice() {
		double totalPrice = expectedEndingValue + leaseFee;
		return totalPrice;
	}

	/**
	 * @param expectedEndingValue the expectedEndingValue to set
	 */
	public void setExpectedEndingValue(double expectedEndingValue) {
		this.expectedEndingValue = expectedEndingValue;
	}

	/**
	 * @param leaseFee the leaseFee to set
	 */
	public void setLeaseFee(double leaseFee) {
		this.leaseFee = leaseFee;
	}

	/**
	 * @param monthlyPayment the monthlyPayment to set
	 */
	public void setMonthlyPayment(double monthlyPayment) {
		this.monthlyPayment = monthlyPayment;
	}

//	@Override
//	public String toString() {
//		return String.format("${member.name()|%s|%s|%s|%s|%s|%s|%s|%s|\\n", expectedEndingValue, leaseFee,
//				monthlyPayment, date, customerName, customerEmail, vehicleSold, totalPrice);
//	}

}
