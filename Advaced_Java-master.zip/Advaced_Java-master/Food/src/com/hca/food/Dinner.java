/**
 * 
 */
package com.hca.food;

/**
 * @author CL89408
 *
 */
public class Dinner {

	String drink, entree, side, dessert;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}

	/**
	 * @param drink
	 * @param entree
	 * @param side
	 * @param dessert
	 */
	public Dinner(String drink, String entree, String side, String dessert) {
		super();
		this.drink = drink;
		this.entree = entree;
		this.side = side;
		this.dessert = dessert;
	}

	/**
	 * @return the drink
	 */
	public String getDrink() {
		return drink;
	}

	/**
	 * @param drink the drink to set
	 */
	public void setDrink(String drink) {
		this.drink = drink;
	}

	/**
	 * @return the entree
	 */
	public String getEntree() {
		return entree;
	}

	/**
	 * @param entree the entree to set
	 */
	public void setEntree(String entree) {
		this.entree = entree;
	}

	/**
	 * @return the side
	 */
	public String getSide() {
		return side;
	}

	/**
	 * @param side the side to set
	 */
	public void setSide(String side) {
		this.side = side;
	}

	/**
	 * @return the dessert
	 */
	public String getDessert() {
		return dessert;
	}

	/**
	 * @param dessert the dessert to set
	 */
	public void setDessert(String dessert) {
		this.dessert = dessert;
	}

	@Override
	public String toString() {
		return String.format("Dinner [drink=%s, entree=%s, side=%s, dessert=%s]", drink, entree, side, dessert);
	}

}
