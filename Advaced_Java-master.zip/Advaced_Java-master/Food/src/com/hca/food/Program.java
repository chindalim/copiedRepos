package com.hca.food;

public class Program {

//	needs to be titled main in order to run
	public static void main(String[] args) {
		// TODO Auto-generated constructor stub

		System.out.print("What's for dinner? \n");

		Dinner din = new Dinner("hot tea", "sushi", "edamame", "mochi");
		System.out.print(din.toString());
//		System.out.print(din);
	}

}
