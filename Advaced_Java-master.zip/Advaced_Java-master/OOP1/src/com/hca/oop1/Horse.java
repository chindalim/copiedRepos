package com.hca.oop1;

public class Horse extends Animal {

	private String owner;

	/**
	 * @param owner string is passed from the animal class
	 */
	public Horse(String name, String owner) {
		super(name);
		System.out.println("Trace -- in Horse (name, owner) constr");
		this.owner = owner;
	}

	/**
	 * @return the owner
	 */
	public String getOwner() {
		return owner;
	}

	/**
	 * @param owner the owner to set
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}

	public void move() {
		System.out.println("trot, trot, trot ---  from horse  Class");
	}

//	@Override method to override the to string in the main app
	public String toString() {
		return String.format("%s [owner=%s 's, getName()=%s]", getClass(), owner, getName());
	}

}
