package com.hca.oop1;

import java.util.*;

public class MainApp {

	public static void skoot(Animal animal, int num) {
		System.out.print(animal.getName() + " ---> ");
		System.out.print(animal.toString() + " toString() ---> ");
		animal.move();
	}

	public MainApp() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<Animal> myList = new ArrayList<Animal>();

		Dog dog = new Dog("Fido", "pug");
		myList.add(dog);

		myList.add(new Dog("BoBo", "Shepsky"));
		myList.add(new Dog("Izzie", "Husky"));
		myList.add(new Dog("Bailee", "Beagle"));

		myList.add(new Horse("Bullet", "Chinda"));
		myList.add(new Horse("Chestnut", "Kaia"));
		myList.add(new Horse("Cosmo", "Kali"));

//		regular for loop
//		for(int i = 0; i < myList.size(); i++) {
//			skoot(myList.get(i));
//			}

//		for each
		int i = 0;
		for (Animal a : myList) {
			skoot(a, i);
			i++;
		}
	}

//		Animal animal1 = new Animal();
//		animal1.setName("SK");
//
//		Dog dog = new Dog();
//		dog.setName("Rambo");
//		dog.setBreed("Pittie");
//
//		System.out.println("Animal's 1 name is " + animal1.getName());
//
//		System.out.printf("Dogs' 1 name is %s and breed is %s ", dog.getName(), dog.getBreed());
//
////		example for second animal
//
//		Animal animal2 = new Animal("SK JR");
//
//		Dog dog2 = new Dog();
//		dog2.setName("BoBo");
//		dog2.setBreed("ShepSky");
//
//		Dog dog3 = new Dog("Bailee", "beagle");
//
//		System.out.println("Animal's 2 name is " + animal2.getName());
//
//		System.out.printf("Dogs' 2 name is %s and breed is %s ", dog2.getName(), dog2.getBreed());
//		System.out.printf("Dogs' 3 name is %s and breed is %s ", dog3.getName(), dog3.getBreed());

//		building a dog
//		
//		Dog dog4 = new Dog("Fido", "pug");
//		dog4.move();
//
////		building a horse 
//
//		Horse horse = new Horse("Cody", "Dana");
//		horse.move();
//		
//		skoot(dog4);
//		skoot(horse);
}
