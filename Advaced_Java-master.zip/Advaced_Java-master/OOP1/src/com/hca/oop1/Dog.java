package com.hca.oop1;

public class Dog extends Animal {
	/**
	 * @param breed
	 */
	public Dog() {
		super();
//		this.breed = breed;
		System.out.print("Trace -- in dog constr");
	}
	
	public Dog(String name) {
		super(name);
//		this.name = name;
		System.out.print("Trace -- in dog (name) constr");
	}
	
	public Dog(String name, String breed) {
		super(name);
		this.breed = breed;
		System.out.print("Trace -- in Dog(name.breed) constr");
	}

	private String breed;

	public String getBreed() {
		return breed;
	}

	public void setBreed(String breed) {
		this.breed = breed;
	}

	public void bark() {
		System.out.println(getName() + "says \"Woof\"!");
	}

}
