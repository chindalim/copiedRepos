/**
 * 
 */
package com.hca.aloha;

/**
 * @author CL89408
 *
 */
public class MainApp {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Aloha Honua");
		
		Person me = new Person("Chinda", 33);
		System.out.println(me.toString());
		System.out.println(me);

	}

}
