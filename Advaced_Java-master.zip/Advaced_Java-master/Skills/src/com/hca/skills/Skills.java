package com.hca.skills;

import java.io.*;

public class Skills {
  public static void main(String[] args) {
    
    // if statement to check for first last and file name

    // created a command line argument
    String firstName = args[0];
    String lastName = args[1];
    String fileName = args[2];

    // creating new skills to append
    String[] skills = new String[13];
    skills[0] = "Angular";
    skills[1] = "Bootstrap";
    skills[2] = "JavaScript";
    skills[3] = "Fiddler";
    skills[4] = "HTML";
    skills[5] = "CSS";
    skills[6] = "GIT";
    skills[7] = "JQuery";
    skills[8] = "Node.JS";
    skills[9] = "TeamWork";
    skills[10] = "Markdown";
    skills[11] = "Debugging";
    skills[12] = "TypeScript";


    // there is a new file and ask if it exists in one line. 
    boolean fileExists = new File("skills.txt").exists();

  // the code that attempts to run
  try {

    FileWriter writer = new FileWriter("skills.txt", true);
    // write to the file and appends
    for (int i = 0; i < skills.length; i++) {
      // if i = 0 and if it does not exists, it skips the carriage return line break
      if (i == 0 && ! fileExists) {
      writer.write(skills[i]);
      } else {
      writer.write("\n" + skills[i]);
      }
    }
      System.out.print(fileName + " updated by " +  firstName + " " + lastName);

  // always close the file when you are finished using it
  writer.close();
  }

  // e is a variable for a type exception and it holds everything
  catch (IOException e) {
  System.out.println(
    // basic error message
  "ERROR: WONK WONK unexpected error occurred");
  e.printStackTrace();
  }
  }
}