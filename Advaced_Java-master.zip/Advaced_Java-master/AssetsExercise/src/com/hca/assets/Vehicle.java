package com.hca.assets;

public class Vehicle extends Asset {

	String makeModel;
	int year, odometer;

	/**
	 * @param makeModel
	 * @param year
	 * @param odometer
	 */
	public Vehicle(String descrption, String dateAquired, double originalCost, String makeModel, int year,
			int odometer) {
		super(descrption, dateAquired, originalCost);
		this.makeModel = makeModel;
		this.year = year;
		this.odometer = odometer;
	}

	/**
	 * @return the makeModel
	 */
	public String getMakeModel() {
		return makeModel;
	}

	/**
	 * @return the year
	 */
	public int getYear() {
		return year;
	}

	/**
	 * @return the odometer
	 */
	public int getOdometer() {
		return odometer;
	}

	/**
	 * @param makeModel the makeModel to set
	 */
	public void setMakeModel(String makeModel) {
		this.makeModel = makeModel;
	}

	/**
	 * @param year the year to set
	 */
	public void setYear(int year) {
		this.year = year;
	}

	/**
	 * @param odometer the odometer to set
	 */
	public void setOdometer(int odometer) {
		this.odometer = odometer;
	}

	@Override
	public double getValue() {
		double value = this.getOriginalCost();
		
		year = 2021 - year;
		
		if (year <= 3) {
			value = (year * value * .97);
		}
		if (year >= 4 && year <= 6) {
			value = (year * value  * .94);
		}
		if (year >= 7 && year <= 10) {
			value = (year * value * .92);
		}
		if (year >= 10) {
			value = (1000.00);
		}
		if((odometer >= 100000) && (!makeModel.contains("Honda")) && (!makeModel.contains("Toyota"))) {
		value -= (0.25 * value);
	}

		return value;
	}

	@Override
	public String toString() {
		return String.format(
				"\n Vehicle's Make and Model = %s, \n The Year is = %s, \n The Odometer = %s, \n The Description = %s, \n Date Aquired = %s, \n Original Cost = %s \n",
				makeModel, year, odometer, description, dateAquired, originalCost);
	}
	
	
}
