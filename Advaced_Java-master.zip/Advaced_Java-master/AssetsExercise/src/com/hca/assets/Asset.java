package com.hca.assets;

// this applies the abstract class to the Asset class 

public abstract class Asset {

	String description, dateAquired;
	double originalCost;

	/**
	 * @param description
	 * @param dateAquired
	 * @param originalCost
	 */
	public Asset(String description, String dateAquired, double originalCost) {
		super();
		this.description = description;
		this.dateAquired = dateAquired;
		this.originalCost = originalCost;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @return the dateAquired
	 */
	public String getDateAquired() {
		return dateAquired;
	}

	/**
	 * @return the originalCost
	 */
	public double getOriginalCost() {
		return originalCost;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @param dateAquired the dateAquired to set
	 */
	public void setDateAquired(String dateAquired) {
		this.dateAquired = dateAquired;
	}

	/**
	 * @param originalCost the originalCost to set
	 */
	public void setOriginalCost(double originalCost) {
		this.originalCost = originalCost;
	}

	// now child classes *MUST* override this method - forces the sub classes to
	// implement their own method
	public abstract double getValue();

// original method
	// public double getValue() {
//		return originalCost;
//	}

}
