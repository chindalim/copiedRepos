package com.hca.assets;

public class House extends Asset {

	String address;
	int condition, sqFt, lotSize;

	/**
	 * @param address
	 * @param condition
	 * @param sqFt
	 * @param lotSize
	 */
	public House(String descrption, String dateAquired, double originalCost, String address, int condition, int sqFt,
			int lotSize) {
		super(descrption, dateAquired, originalCost);
		this.address = address;
		this.condition = condition;
		this.sqFt = sqFt;
		this.lotSize = lotSize;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @return the condition
	 */
	public int getCondition() {
		return condition;
	}

	/**
	 * @return the sqFt
	 */
	public int getSqFt() {
		return sqFt;
	}

	/**
	 * @return the lotSize
	 */
	public int getLotSize() {
		return lotSize;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @param condition the condition to set
	 */
	public void setCondition(int condition) {
		this.condition = condition;
	}

	/**
	 * @param sqFt the sqFt to set
	 */
	public void setSqFt(int sqFt) {
		this.sqFt = sqFt;
	}

	/**
	 * @param lotSize the lotSize to set
	 */
	public void setLotSize(int lotSize) {
		this.lotSize = lotSize;
	}

	@Override
	public double getValue() {
		double value = 0;
		if (condition == 1) {
			value = ((sqFt * 180.00) + (lotSize * .25));
		}
		if (condition == 2) {
			value = ((sqFt * 130.00) + (lotSize * .25));
		}
		if (condition == 3) {
			value = ((sqFt * 90.00) + (lotSize * .25));
		}
		if (condition == 4) {
			value = ((sqFt * 80.00) + (lotSize * .25));
		}
		if (description.contains("Oly") || description.contains("Honolulu")) {
			value = value * 2.0;
		}
		return value;
	}

	@Override
	public String toString() {
		return String.format(
				"\n House address = %s, \n condition is a = %s, \n Total Square Footage = %s, \n Total Lot Size Square Footage = %s, \n Home's description = %s, \n Date Aquired = %s, \n Original Cost = %s \n",
				address, condition, sqFt, lotSize, description, dateAquired, originalCost);
	}

}
