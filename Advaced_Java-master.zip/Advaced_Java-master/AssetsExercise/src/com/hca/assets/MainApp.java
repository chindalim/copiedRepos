package com.hca.assets;

import java.util.ArrayList;

public class MainApp {

	public static void display(Asset asset) {
		System.out.print(asset.toString() + " toString() ---> ");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Asset> myAssets = new ArrayList<Asset>();
//		
//		House(String descrption, String dateAquired, double originalCost, String address, int condition, int sqFt,
//				int lotSize)		
		House house1 = new House("Chinda's Oly House", "05.04.2021", 410000, "123 Martin Drive", 2, 2200, 29000);
		House house2 = new House("Chinda's Honolulu Condo", "10.12.2021", 580000, "1233 Ala Moana Drive", 1, 1000,
				1500);
		House house3 = new House("Rental Honolulu Condo", "10.12.2021", 380000, "1233 Ala Moana Drive", 1, 700, 899);
		myAssets.add(house1);
		myAssets.add(house2);
		myAssets.add(house3);

//		 Vehicle(String descrption, String dateAquired, double originalCost, String makeModel, int year,
//					int odometer) 
		Vehicle car1 = new Vehicle("Civic", "02.10.2016", 1800, "Honda", 1994, 198000);
		Vehicle car2 = new Vehicle("Cherokee", "12.20.2016", 23000, "Jeep", 2015, 102333);
		Vehicle car3 = new Vehicle("F150", "12.20.2011", 11000, "Ford", 2004, 152333);
		myAssets.add(car1);
		myAssets.add(car2);
		myAssets.add(car3);

		for (int i = 0; i < myAssets.size(); i++) {
			String message = "";
			if (myAssets.get(i) instanceof House) {
				House house = (House) myAssets.get(i);
				message = house.toString() + "Method to calculate value: " + house.getValue() + " \n";
			} else if (myAssets.get(i) instanceof Vehicle) {
				Vehicle vehicle = (Vehicle) myAssets.get(i);
				message = vehicle.toString() + "Method to calculate value: " + vehicle.getValue() + " \n";
			}
			System.out.print(message);
		}

		double totalAssetValue = 0;

		for (Asset a : myAssets) {
			totalAssetValue += a.getValue();
		}
		System.out.println("\n The total value of my assets are:  $" + totalAssetValue);
	}
}
